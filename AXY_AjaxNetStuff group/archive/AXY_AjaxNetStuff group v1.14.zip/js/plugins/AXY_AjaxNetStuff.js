//=============================================================================
// XueYu Plugins - Ajax Net Stuff
// AXY_AjaxNetStuff.js
// Version: 1.14
// License: BSD
//=============================================================================
 /*:
 * @plugindesc v1.14 This plugin support rmmv with ajax net stuff.
 * @author XueYu Plugins
 *
 *
 * @param URL
 * @desc The url of your ajax net stuff.
 * @default http://exchange.digitcoin.org/zhongchou/product/id/20
 *
 * @param EnableTopList
 * @desc Enable TopList? true/false
 * @default true
 *
 * @param TopListHAlign
 * @desc The Horizontal align of TopList box. left/right
 * @default right
 *
 * @param TopListVAlign
 * @desc The Vertical align of TopList box. top/bottom
 * @default top
 *
 * @param X
 * @desc The x position of TopList box.
 * @default 0
 *
 * @param Y
 * @desc The y position of TopList box.
 * @default 0
 *
 * @param Width
 * @desc The TopList box width.
 * @default 400
 *
 * @param Height
 * @desc The TopList box height.
 * @default 0
 *
 * @param backgroundcolor
 * @desc #000000-#FFFFFF or RGBA(R,G,B,A) or red blue green yellow etc.
 * @default black
 *
 * @param opacity
 * @desc The css opacity. 0-1
 * @default 1
 *
 * @param TextColor
 * @desc #000000-#FFFFFF or RGBA(R,G,B,A) or red blue green yellow etc.
 * @default yellow
 *
 * @param TextAlign
 * @desc Button align. left/center/right
 * @default right
 *
 * @param fontsize
 * @desc The size of text.
 * @default 12
 *
 * @param zIndex
 * @desc The css zIndex.
 * @default 50000
 *
 * @param ImgWidth
 * @desc The TopList Img width.
 * @default 50
 *
 * @param ImgHeight
 * @desc The TopList Img Height.
 * @default 50
 *
 * @param ImgOpacity
 * @desc The css opacity of img. 0-1
 * @default 0.2
 *
 * @param LoginButtonText
 * @desc Login Button Text
 * @default Login
 *
 * @param LoginButtonColor
 * @desc #000000-#FFFFFF or RGBA(R,G,B,A) or red blue green yellow etc.
 * @default yellow
 *
 * @param LoginButtonOpacity
 * @desc The css opacity of login button. 0-1
 * @default 1
 *
 * @param LoginButtonFontSize
 * @desc The size of Login Button.
 * @default 16
 *
 * @param LoadingText
 * @desc Loading Text
 * @default Loading
 *
 * @param LastestText
 * @desc Lastest Text
 * @default Lastest
 *
 * @param ActorText
 * @desc Actor Text
 * @default Actor
 *
 * @param LevelText
 * @desc Level Text
 * @default Level
 *
 * @param GoldText
 * @desc Gold Text
 * @default Gold
 *
 * @param StepsText
 * @desc Steps Text
 * @default Steps
 *
 * @param PlayTimeText
 * @desc Play Time Text
 * @default Play Time
 *
 * @param SaveTimesText
 * @desc Save Times Text
 * @default Save Times
 *
 * @param BattleTimesText
 * @desc Battle Times Text
 * @default Battle Times
 *
 * @param VictoryTimesText
 * @desc Victory Times Text
 * @default Victory Times
 *
 * @param EscapeTimesText
 * @desc Escape Times Text
 * @default Escape Times
 *
 * @param EnableCoupon
 * @desc Enable coupon? true/false
 * @default true
 *
 * @param CouponText
 * @desc Coupon Text
 * @default Coupon
 *
 * @param EnableVerCheck
 * @desc Enable VerCheck? true/false
 * @default true
 *
 * @param Version
 * @desc The game version.
 * @default 1.0
  *
 * @param VerCheckX
 * @desc The x position of VerCheck box.
 * @default 0
 *
 * @param VerCheckY
 * @desc The y position of VerCheck box.
 * @default 0
 *
 * @param VerCheckWidth
 * @desc The VerCheck box width with % percent or only number.
 * @default 100%
 *
 * @param VerCheckbackgroundcolor
 * @desc #000000-#FFFFFF or RGBA(R,G,B,A) or red blue green yellow etc.
 * @default rgba(0,0,0,0.7);
 *
 * @param VerCheckopacity
 * @desc The css opacity. 0-1
 * @default 1
 *
 * @param VerCheckTextColor
 * @desc #000000-#FFFFFF or RGBA(R,G,B,A) or red blue green yellow etc.
 * @default white
 *
 * @param VerCheckTextAlign
 * @desc left/center/right
 * @default center
 *
 * @param VerCheckingText
 * @desc Ver Checking Text
 * @default Ver Checking
 *
 * @param NoNewText
 * @desc No New Text
 * @default No New
 *
 * @param HaveNewText
 * @desc Have New  Text
 * @default Have New: 
 *
 * @param LinkText
 * @desc Link Text
 * @default Link
 *
 * @param EnableLoginGift
 * @desc Enable Login Gift? true/false
 * @default true
 *
 * @param LoginGift
 * @desc format:'type:id:amount;'. type:gold=0,item=1,weapon=2,armor=3. for more detail check help.
 * @default 0:0:100;1:1:1;
 *
 * @param EnableCloudSave
 * @desc Enable Cloud Save? true/false
 * @default true
 *
 * @param CloudSaveText
 * @desc Cloud Save Text
 * @default Cloud Save
 *
 * @param EnableChat
 * @desc Enable Chat? true/false
 * @default true
 *
 * @param EnableDanmu
 * @desc Enable Danmu? true/false
 * @default true
 *
 * @param DanmuSpeed
 * @desc Danmu Speed? unit: ms
 * @default 5000
 *
 * @param DanmuInterval
 * @desc Danmu Interval? unit: ms
 * @default 1000
 *
 * @param EnableShopInGame
 * @desc Enable ShopInGame? true/false
 * @default true
 *
 * @param ShopInGameText
 * @desc ShopInGame Text
 * @default Shop In Game
 *
 * @param ShopInGameSoldOutText
 * @desc ShopInGame Sold Out Text
 * @default Sold Out
 *
 * @param ShopInGameColumn
 * @desc ShopInGame Column
 * @default 4
 *
 * @param LoginCommonEventId
 * @desc Do common event by this id when player logged in. Set 0 to disable.
 * @default 0
 *
 * @help
 * Introduction
 * This plugin support rmmv with ajax net stuff.
 * Easy to use of you just copy your own url to here.
 * And then you will see it worked.
 * 
 * Example:
 * To open Coupon dialog,
 * AXY_AjaxCoupon.show();
 * To close Coupon dialog,
 * AXY_AjaxCoupon.hide();
 *
 * LoginGift
 * format:'type:id:amount;'. type:gold=0,item=1,weapon=2,armor=3.
 * example:
 * give 10 gold and 1 item1:'0:0:10;1:1:1;'
 * give 10 gold and 1 weapon1:'0:0:10;2:1:1;'
 *
 * changelog
 * 1.14 2017.3.26
 * add do common event by id when player logged in;
 * 1.13 2017.2.6
 * fix shopInGame can not scroll on android;
 * 1.12 2017.2.4
 * close open browser when click login button on pc;
 * 1.11 2017.2.1
 * bind login button with click;
 * fix sometimes crash when danmu refresh;
 * fix maybe crash when click login button before game ready;
 * add reg button to open link with browser in game;
 * 1.10 2017.1.29
 * fix vercheck have new link can not click on android;
 * 1.09 2017.1.28
 * modify complate color to gray in coupon section;
 * 1.08 2017.1.25
 * fix some issus, add try catch;
 * 1.07 2017.1.25
 * fix danmu issus, send danmu on map after battle may display on battle and map;
 * limit danmu and chat length to 20;
 * add shop in game;
 * 1.06 2017.1.20
 * add coupon switch and text;
 * add coupon menu command;
 * 1.05 2017.1.19
 * add danmu system;
 * 1.04 2017.1.17
 * add chat system;
 * 1.03 2017.1.16
 * add cloud save;
 * fix android login and cloud save;
 * 1.02 2017.1.13
 * support login on android;
 * fix cannot open ime after close ime on coupon dialog;
 * fix login gift unlimited got;
 * 1.01 2017.1.8
 * fix ajax muilt post;
 * add trim input space and html tag on left/center/right;
 * add id to div;
 * 1.0 2016.12.27
 * first release.
 */

// Imported
var Imported = Imported || {};
Imported.AXY_AjaxNetStuff = true;

// Parameter Variables
var AXY = AXY || {};
AXY.AjaxNetStuff = AXY.AjaxNetStuff || {};

AXY.AjaxNetStuff.Parameters = PluginManager.parameters('AXY_AjaxNetStuff');
AXY.AjaxNetStuff.Param = AXY.AjaxNetStuff.Param || {};
AXY.AjaxNetStuff.Alias = AXY.AjaxNetStuff.Alias || {};

// 
AXY.AjaxNetStuff.Param.URL = String(AXY.AjaxNetStuff.Parameters['URL']);
AXY.AjaxNetStuff.Param.EnableTopList = AXY.AjaxNetStuff.Parameters['EnableTopList'].toLowerCase() === 'true';
AXY.AjaxNetStuff.Param.X = parseInt(AXY.AjaxNetStuff.Parameters['X']);
AXY.AjaxNetStuff.Param.Y = parseInt(AXY.AjaxNetStuff.Parameters['Y']);
AXY.AjaxNetStuff.Param.Width = parseInt(AXY.AjaxNetStuff.Parameters['Width']);
AXY.AjaxNetStuff.Param.Height = parseInt(AXY.AjaxNetStuff.Parameters['Height']);
AXY.AjaxNetStuff.Param.backgroundcolor = String(AXY.AjaxNetStuff.Parameters['backgroundcolor']);
AXY.AjaxNetStuff.Param.opacity = parseFloat(AXY.AjaxNetStuff.Parameters['opacity']);
AXY.AjaxNetStuff.Param.TextColor = String(AXY.AjaxNetStuff.Parameters['TextColor']);
AXY.AjaxNetStuff.Param.TextAlign = String(AXY.AjaxNetStuff.Parameters['TextAlign']);
AXY.AjaxNetStuff.Param.fontsize = parseInt(AXY.AjaxNetStuff.Parameters['fontsize']);
AXY.AjaxNetStuff.Param.zIndex = parseInt(AXY.AjaxNetStuff.Parameters['zIndex']);
AXY.AjaxNetStuff.Param.ImgWidth = parseInt(AXY.AjaxNetStuff.Parameters['ImgWidth']);
AXY.AjaxNetStuff.Param.ImgHeight = parseInt(AXY.AjaxNetStuff.Parameters['ImgHeight']);
AXY.AjaxNetStuff.Param.ImgOpacity = parseFloat(AXY.AjaxNetStuff.Parameters['ImgOpacity']);
AXY.AjaxNetStuff.Param.LoginButtonText = String(AXY.AjaxNetStuff.Parameters['LoginButtonText']);
AXY.AjaxNetStuff.Param.LoginButtonColor = String(AXY.AjaxNetStuff.Parameters['LoginButtonColor']);
AXY.AjaxNetStuff.Param.LoginButtonOpacity = parseFloat(AXY.AjaxNetStuff.Parameters['LoginButtonOpacity']);
AXY.AjaxNetStuff.Param.LoginButtonFontSize = parseInt(AXY.AjaxNetStuff.Parameters['LoginButtonFontSize']);
//text
AXY.AjaxNetStuff.Param.LoadingText = String(AXY.AjaxNetStuff.Parameters['LoadingText']);
AXY.AjaxNetStuff.Param.LastestText = String(AXY.AjaxNetStuff.Parameters['LastestText']);
AXY.AjaxNetStuff.Param.ActorText = String(AXY.AjaxNetStuff.Parameters['ActorText']);
AXY.AjaxNetStuff.Param.LevelText = String(AXY.AjaxNetStuff.Parameters['LevelText']);
AXY.AjaxNetStuff.Param.GoldText = String(AXY.AjaxNetStuff.Parameters['GoldText']);
AXY.AjaxNetStuff.Param.StepsText = String(AXY.AjaxNetStuff.Parameters['StepsText']);
AXY.AjaxNetStuff.Param.PlayTimeText = String(AXY.AjaxNetStuff.Parameters['PlayTimeText']);
AXY.AjaxNetStuff.Param.SaveTimesText = String(AXY.AjaxNetStuff.Parameters['SaveTimesText']);
AXY.AjaxNetStuff.Param.BattleTimesText = String(AXY.AjaxNetStuff.Parameters['BattleTimesText']);
AXY.AjaxNetStuff.Param.VictoryTimesText = String(AXY.AjaxNetStuff.Parameters['VictoryTimesText']);
AXY.AjaxNetStuff.Param.EscapeTimesText = String(AXY.AjaxNetStuff.Parameters['EscapeTimesText']);
//coupon
AXY.AjaxNetStuff.Param.EnableCoupon = AXY.AjaxNetStuff.Parameters['EnableCoupon'].toLowerCase() === 'true';
AXY.AjaxNetStuff.Param.CouponText = String(AXY.AjaxNetStuff.Parameters['CouponText']);
//vercheck
AXY.AjaxNetStuff.Param.EnableVerCheck = AXY.AjaxNetStuff.Parameters['EnableVerCheck'].toLowerCase() === 'true';
//logingift
AXY.AjaxNetStuff.Param.EnableLoginGift = AXY.AjaxNetStuff.Parameters['EnableLoginGift'].toLowerCase() === 'true';
//cloudsave
AXY.AjaxNetStuff.Param.EnableCloudSave = AXY.AjaxNetStuff.Parameters['EnableCloudSave'].toLowerCase() === 'true';
AXY.AjaxNetStuff.Param.CloudSaveText = String(AXY.AjaxNetStuff.Parameters['CloudSaveText']);
//chat
AXY.AjaxNetStuff.Param.EnableChat = AXY.AjaxNetStuff.Parameters['EnableChat'].toLowerCase() === 'true';
//danmu
AXY.AjaxNetStuff.Param.EnableDanmu = AXY.AjaxNetStuff.Parameters['EnableDanmu'].toLowerCase() === 'true';
AXY.AjaxNetStuff.Param.DanmuSpeed = parseInt(AXY.AjaxNetStuff.Parameters['DanmuSpeed']);
AXY.AjaxNetStuff.Param.DanmuInterval = parseInt(AXY.AjaxNetStuff.Parameters['DanmuInterval']);
AXY.AjaxNetStuff.Param.DanmuSwitch = true;
AXY.AjaxNetStuff.Param.DanmuObj = {};
AXY.AjaxNetStuff.Param.DanmuObj.Troop = [];
AXY.AjaxNetStuff.Param.DanmuObj.Map = [];
//shopingame
AXY.AjaxNetStuff.Param.EnableShopInGame = AXY.AjaxNetStuff.Parameters['EnableShopInGame'].toLowerCase() === 'true';
AXY.AjaxNetStuff.Param.ShopInGameText = String(AXY.AjaxNetStuff.Parameters['ShopInGameText']);
AXY.AjaxNetStuff.Param.ShopInGameSoldOutText = String(AXY.AjaxNetStuff.Parameters['ShopInGameSoldOutText']);
AXY.AjaxNetStuff.Param.ShopInGameColumn = parseInt(AXY.AjaxNetStuff.Parameters['ShopInGameColumn']);
AXY.AjaxNetStuff.Param.ShopInGameFetchDone = false;
AXY.AjaxNetStuff.Param.ShopInGameFetchHbid = 0;
AXY.AjaxNetStuff.Param.ShopInGameFee = 0;
//LoginCommonEventId
AXY.AjaxNetStuff.Param.LoginCommonEventId = parseInt(AXY.AjaxNetStuff.Parameters['LoginCommonEventId']);

//main
//ajax shopingame
if (AXY.AjaxNetStuff.Param.EnableShopInGame) {
	//=============================================================================
	// ** Window MenuCommand
	//=============================================================================	

	//==============================
	// * make Command List
	//==============================
	AXY.AjaxNetStuff.Alias.addOriginalCommandsShopInGame = Window_MenuCommand.prototype.addOriginalCommands;
	Window_MenuCommand.prototype.addOriginalCommands = function() {
		AXY.AjaxNetStuff.Alias.addOriginalCommandsShopInGame.call(this);
		this.addCommand(AXY.AjaxNetStuff.Param.ShopInGameText, 'ShopInGame', true);
	};
		
	//=============================================================================
	// ** Scene Menu
	//=============================================================================	

	//==============================
	// * create Command Window
	//==============================
	AXY.AjaxNetStuff.Alias.createCommandWindowShopInGame = Scene_Menu.prototype.createCommandWindow;
	Scene_Menu.prototype.createCommandWindow = function() {
		AXY.AjaxNetStuff.Alias.createCommandWindowShopInGame.call(this); 
		this._commandWindow.setHandler('ShopInGame',      this.commandShopInGame.bind(this));
		/*if (Imported.MOG_TimeSystem && Moghunter.timeWindow_menu) {	
			this._commandWindow.height -= this._commandWindow.itemHeight();
		};*/
	};

	//==============================
	// * Shop In Game
	//==============================
	Scene_Menu.prototype.commandShopInGame = function() {
		AXY_AjaxShopInGame.show();
		// Close option window
		SceneManager.pop();	
	};
	
	//display html first
	var AXYAjaxShopInGameTemplate = 
					'<div class="AXYAjaxShopInGame" id="AXYAjaxShopInGame">' +
						'<div class="AXYAjaxShopInGameBG"></div><div class="AXYAjaxShopInGameGold">' +
						'<input type="button" class="AXYAjaxShopInGameButtonGold" id="AXYAjaxShopInGameButtonGold" value="DTC" /><input type="hidden" name="balance" value="" />' +
						'<input type="button" class="AXYAjaxShopInGameButtonClose" id="AXYAjaxShopInGameButtonUp" value="上一页" />' +
						'<input type="button" class="AXYAjaxShopInGameButtonClose" id="AXYAjaxShopInGameButtonDown" value="下一页" />' +
						'<input type="button" class="AXYAjaxShopInGameButtonClose" id="AXYAjaxShopInGameButtonClose" value="关闭" /></div>' +
						'<div id="AXYAjaxShopInGameBody"></div>'+
					'</div>';
	var AXYAjaxShopInGameStyleCss = 
			'.AXYAjaxShopInGame{overflow-y:scroll;position:fixed;top:10px;left:.5%;z-index:10000;display:none;margin:0 auto;width:98%;height:0;text-align:center;border:3px solid #fff;border-radius:10px;}'+
			'.AXYAjaxShopInGame .AXYAjaxShopInGameBG{position:absolute;width:100%;height:100%;background:#000;opacity:.5}'+
			'.AXYAjaxShopInGame .AXYAjaxShopInGameGold{z-index:20000;margin-top:1%;width:100%;height:10%;}'+
			'.AXYAjaxShopInGame .AXYAjaxShopInGameButtonClose, .AXYAjaxShopInGameButtonGold{position:relative;outline:0;border:1px solid #fff;border-radius:5px;background-color:rgba(0,0,0,0.7);opacity:1;color:#fff;font-size:24px;}'+
			'.AXYAjaxShopInGame .AXYAjaxShopInGameButtonClose, .AXYAjaxShopInGameButtonGold{top:0;z-index:10000;margin-left:2%;width:10%;height:50px;cursor:pointer}'+
			'.AXYAjaxShopInGame .AXYAjaxShopInGameButtonGold{width:40%;cursor:default;}'+
			'.AXYAjaxShopInGame .AXYAjaxShopInGameBody{}'+
			'.AXYAjaxShopInGameButton{position:relative;top:0;z-index:10000;margin:1%;padding:5px;width:'+
			parseInt(100/AXY.AjaxNetStuff.Param.ShopInGameColumn-2)+'%;height:15pc;outline:0;border:1px solid #fff;border-radius:5px;background-color:rgba(0,0,0,0.5);color:#fff;font-size:24px;cursor:pointer}'+
			'.AXYAjaxShopInGameButtonDiv1{display:block;overflow:hidden;width:100%;height:190px;border-bottom:1px solid #fff;text-align:left;font-size:20px}'+
			'.AXYAjaxShopInGameButtonDiv2{display:block;width:100%;height:40px;line-height:40px}';
	$('body').append(AXYAjaxShopInGameTemplate);
	$('#AXYAjaxShopInGame').append('<style type="text/css">'+AXYAjaxShopInGameStyleCss+'</style>');
	
	var AXYAjaxShopInGameConfirmTemplate = 
				'<div class="AXYAjaxShopInGameConfirm" id="AXYAjaxShopInGameConfirm">' +
					'<div class="AXYAjaxShopInGameConfirmBG"></div>' +
					'<input type="text" readonly="readonly" class="AXYAjaxShopInGameConfirmInput" id="AXYAjaxShopInGameConfirmFee" />' +
					'<input type="password" class="AXYAjaxShopInGameConfirmInput" id="AXYAjaxShopInGameConfirmInputPwd" placeholder="输入交易密码" />' +
					'<input type="button" class="AXYAjaxShopInGameConfirmButton" id="AXYAjaxShopInGameConfirmButtonUse" value="确认" />' +
					'<input type="button" class="AXYAjaxShopInGameConfirmButton" id="AXYAjaxShopInGameConfirmButtonClose" value="取消" />' +
				'</div>';
	var AXYAjaxShopInGameConfirmStyleCss = 
			'.AXYAjaxShopInGameConfirm{position:fixed;top:20%;left:20%;z-index:10000;display:none;margin:0 auto;width:0%;height:220px;text-align:center;}'+
			'.AXYAjaxShopInGameConfirm .AXYAjaxShopInGameConfirmBG{position:absolute;width:100%;height:100%;border:3px solid #fff;border-radius:10px;background:#000;opacity:.9}'+
			'.AXYAjaxShopInGameConfirm .AXYAjaxShopInGameConfirmInput{margin:15px 0;text-align:center;width:80%;height:50px;imeMode:active}'+
			'.AXYAjaxShopInGameConfirm .AXYAjaxShopInGameConfirmButton,.AXYAjaxShopInGameConfirm .AXYAjaxShopInGameConfirmInput{position:relative;outline:0;border:1px solid #fff;border-radius:5px;background-color:rgba(0,0,0,1);color:#fff;font-size:24px;}'+
			'.AXYAjaxShopInGameConfirm .AXYAjaxShopInGameConfirmButton{top:0;z-index:10000;margin-left:2%;width:30%;height:3pc;word-spacing:20px;cursor:pointer}';
	$('body').append(AXYAjaxShopInGameConfirmTemplate);
	$('#AXYAjaxShopInGameConfirm').append('<style type="text/css">'+AXYAjaxShopInGameConfirmStyleCss+'</style>');


	var AXY_AjaxShopInGameURL = AXY.AjaxNetStuff.Param.URL.replace('zhongchou','rmmvgame').replace('product','rmmvgameshopingame');
	
	//then bind action
	var AXY_AjaxShopInGame = {
		show: function () {
			if(!AXY.AjaxNetStuff.Param.Loggedin){
				$.toaster({ message : '请先登录', color:'white'});
				return;
			}
			
			$('#AXYAjaxShopInGame').stop().show().animate({"height": "96%"}, "normal", '', function(){
				$('.AXYAjaxShopInGameBG').stop().show().animate({"height": ($('#AXYAjaxShopInGame')[0].scrollHeight)+'px'}, "normal");
			});

			$gameSystem.setTouchMoveEnabled(false);

			var css =
			{
				'font-family':	$gameSystem ? Window_Base.prototype.standardFontFace : 'GameFont'
			};

			$('.AXYAjaxShopInGame').css(css);
			//$('.AXYAjaxShopInGameButton').css(css);
			
			$('#AXYAjaxShopInGameButtonClose').unbind('click touchstart').bind('click touchstart',function() {
				AXY_AjaxShopInGame.hide();
			});
			
			/*$('#AXYAjaxShopInGame').scroll(function() {
				$.toaster({ message : '滚动了', color:'white'});
				$('#AXYAjaxShopInGame').scrollTop(100);
			});*/
			var scrollTop = 0;
			$('#AXYAjaxShopInGameButtonUp').unbind('click touchend').bind('click touchend',function() {
				scrollTop -= 200;
				if(scrollTop<=0){
					scrollTop = 0;
					$('#AXYAjaxShopInGame').scrollTop(scrollTop);
					$('.AXYAjaxShopInGameGold').css('position', '');
				}
				else{
					$('#AXYAjaxShopInGame').scrollTop(scrollTop);
					//$('.AXYAjaxShopInGameGold').css('position', 'fixed');
				}
				$.toaster({ message : '滚动到'+scrollTop, color:'white'});
			});
			$('#AXYAjaxShopInGameButtonDown').unbind('click touchend').bind('click touchend',function() {
				scrollTop += 200;
				$('#AXYAjaxShopInGame').scrollTop(scrollTop);
				$('.AXYAjaxShopInGameGold').css('position', 'fixed');
				$.toaster({ message : '滚动到'+scrollTop, color:'white'});
			});
			
			if(AXY.AjaxNetStuff.Param.ShopInGameFetchDone){
				return;
			}
			
			$.ajax({
				url: AXY_AjaxShopInGameURL,
				type: 'POST',
				dataType: 'json',
				data: {sid: AXY.AjaxNetStuff.Param.sid, action:'fetchall'},
				success: function (data) {
					//console.log(data);
					if (data.status) {
						//console.log(data);
						//$('.AXYAjaxTopListTbody').empty();
						//console.log(data);
						try{
							$('#AXYAjaxShopInGameButtonGold').val(data['balance']+'DTC');
							$('.AXYAjaxShopInGameGold').find("input[name='balance']").val($.unformatMoney(data['balance']));
							
							
							var str = '';
							$.each(data['hb'], function(index) {
								var obj = data['hb'][index];
								//console.log(obj1.jsonstr);
								//var obj = $.parseJSON($.parseJSON(obj1.jsonstr));
								//console.log(obj);
								//var time1 = new Date((obj1.lasttime).replace(new RegExp("-","gm"),"/")).Format("hh:mm"); 
								if(obj.endflag){
									str += '<button class="AXYAjaxShopInGameButton"><span class="AXYAjaxShopInGameButtonDiv1">'+obj.neirong+'</span><span class="AXYAjaxShopInGameButtonDiv2">'+AXY.AjaxNetStuff.Param.ShopInGameSoldOutText+'</span><input type="hidden" name="hbid" value="soldout" /></button>';
								}
								else{
									str += '<button class="AXYAjaxShopInGameButton"><span class="AXYAjaxShopInGameButtonDiv1">'+obj.neirong+'</span><span class="AXYAjaxShopInGameButtonDiv2">'+parseFloat($.formatMoney(parseFloat(obj.fee)+parseFloat(obj.yunfei), 8))+'DTC</span><input type="hidden" name="hbid" value="'+obj.id+'" /><input type="hidden" name="fee" value="'+(parseFloat(obj.fee)+parseFloat(obj.yunfei))+'" /></button>';
								}
							});
							//$('.AXYAjaxTopListTbody').html(str);
							$('#AXYAjaxShopInGameBody').html(str);

							//bind click when html ready
							$('.AXYAjaxShopInGameButton').unbind('click touchend').bind('click touchend',function() {
								//console.log($(this));
								//console.log($(this).index());
								//console.log($(this).find("input[name='hbid']").val());
								if($(this).find("input[name='hbid']").val() == 'soldout'){
									$.toaster({ message : AXY.AjaxNetStuff.Param.ShopInGameSoldOutText, color:'white'});
									return;
								}
								if($('#AXYAjaxShopInGameButtonGold').find("input[name='balance']").val() == 0){
									$.toaster({ message : '余额不足，请先充值兑换！', color:'white'});
									return;
								}
								
								if($(this).disabled){
									//console.log($('#AXYAjaxShopInGameButtonUse')[0].disabled);
									return;
								}
								//console.log($('#AXYAjaxShopInGameButtonUse'));
								//console.log($('#AXYAjaxShopInGameButtonUse')[0].disabled);

								$(this).attr("disabled", true);
								var hbitem = $(this);
								//$('#AXYAjaxShopInGameButtonUse').val("sending");
								//console.log($('#AXYAjaxShopInGameButtonUse'));
								//console.log(typeof($('#AXYAjaxShopInGameButtonUse')[0].disabled));
								//return;
								
								//confirm
								$('#AXYAjaxShopInGameConfirm').stop().show().animate({"width": "60%"}, "normal");
								
								AXY.AjaxNetStuff.Param.ShopInGameFee = parseFloat($(this).find("input[name='fee']").val());
								$('#AXYAjaxShopInGameConfirmFee').val(parseFloat($.formatMoney(AXY.AjaxNetStuff.Param.ShopInGameFee, 8))+'DTC');
								//$('#AXYAjaxShopInGameButtonGold').find("input[name='balance']").val(data['balance']);
								
								var css =
								{
									'font-family':	$gameSystem ? Window_Base.prototype.standardFontFace : 'GameFont'
								};
								$('#AXYAjaxShopInGameConfirm').css(css);
								
								$('#AXYAjaxShopInGameConfirmInputPwd').focus();
								
								$('#AXYAjaxShopInGameConfirmInputPwd').keydown(function (e) {
									if (e.keyCode == 8) {
										var _name = this.value.slice(0, this.value.length - 1);
										this.value = _name;
									}
								}); 
								$('#AXYAjaxShopInGameConfirmInputPwd').unbind('click touchend').bind('click touchend',function () {
									$('#AXYAjaxShopInGameConfirmInputPwd').focus();
								}); 
								
								$('#AXYAjaxShopInGameConfirmButtonClose').unbind('click touchstart').bind('click touchstart',function() {
									$('#AXYAjaxShopInGameConfirm').stop().animate({"width": "0"}, "normal", function() {
										$(this).hide();
										//$(this).remove();
									});
									hbitem.attr("disabled", false);
								});
								
								AXY.AjaxNetStuff.Param.ShopInGameFetchHbid = $(this).find("input[name='hbid']").val();
								//console.log(AXY.AjaxNetStuff.Param.ShopInGameFetchHbid);
								//console.log($(this).find("input[name='hbid']").val());
								$('#AXYAjaxShopInGameConfirmButtonUse').unbind('click touchstart').bind('click touchstart',function() {
									//console.log(AXY.AjaxNetStuff.Param.ShopInGameFetchHbid);
									if($('#AXYAjaxShopInGameConfirmInputPwd').val() == ''){
										$.toaster({ message : '不能为空', color:'red'});
										return;
									}
									//console.log($('#AXYAjaxShopInGameConfirmInputPwd').val());
									$(this).attr("disabled", true);
									$(this).val("sending");
									$.ajax({
										url: AXY_AjaxShopInGameURL,
										type: 'POST',
										dataType: 'json',
										data: {sid: AXY.AjaxNetStuff.Param.sid, action: 'fetchone', hbid: AXY.AjaxNetStuff.Param.ShopInGameFetchHbid, pw: $('#AXYAjaxShopInGameConfirmInputPwd').val()},
										success: function (data) {
											//console.log(data);
											if (data.status) {
												//console.log(data);
												$.toaster({ message : "支付成功！"});
												//console.log($('.AXYAjaxShopInGameGold').find("input[name='balance']").val());
												//console.log(AXY.AjaxNetStuff.Param.ShopInGameFee);
												$('#AXYAjaxShopInGameButtonGold').val(parseFloat($.formatMoney(parseFloat($('.AXYAjaxShopInGameGold').find("input[name='balance']").val())-AXY.AjaxNetStuff.Param.ShopInGameFee, 8))+'DTC');
												$('.AXYAjaxShopInGameGold').find("input[name='balance']").val(parseFloat($('.AXYAjaxShopInGameGold').find("input[name='balance']").val())-AXY.AjaxNetStuff.Param.ShopInGameFee);
												
												var obj = $.parseJSON(data['content']);
												//console.log(obj);
												$.each(obj, function(index) {
													//console.log(obj[index]);
													switch(obj[index].item){
														case 0:
															$gameParty.gainGold(obj[index].num,0,0);
															if(!AXY.Toast.Param.DisplayGainGold){
																$.toaster({ message : "+"+obj[index].num+TextManager.currencyUnit});
															}
															break;
														case 1:
															$gameParty.gainItem($dataItems[obj[index].id],obj[index].num,0,0);
															if(!AXY.Toast.Param.DisplayGainItem){
																$.toaster({ message : "+"+obj[index].num+$dataItems[obj[index].id].name});
															}
															break;
														case 2:
															$gameParty.gainItem($dataWeapons[obj[index].id], obj[index].num,0,0,0);
															if(!AXY.Toast.Param.DisplayGainItem){
																$.toaster({ message : "+"+obj[index].num+$dataWeapons[obj[index].id].name});
															}
															break;
														case 3:
															$gameParty.gainItem($dataArmors[obj[index].id], obj[index].num,0,0,0);
															if(!AXY.Toast.Param.DisplayGainItem){
																$.toaster({ message : "+"+obj[index].num+$dataArmors[obj[index].id].name});
															}
															break;
														default:
															//console.log(typeof(obj[index].num));
															break;
													}
												});
												
												setTimeout(function()
												{
													$.toaster({ message : "众筹游戏《"+data.gamename+"》感谢您的支持！"});
													AXY_AjaxCoupon.hide();
												}, 3000);
											} else{
												console.log(data);
												$.toaster({ message : data.info+', ERRORCODE: '+data.error, color:'red'});
											};
											$('#AXYAjaxShopInGameConfirmButtonUse').attr("disabled", false);
											$('#AXYAjaxShopInGameConfirmButtonUse').val("确认");
										},
										error:function (XMLHttpRequest, textStatus, errorThrown) {
											//console.log(XMLHttpRequest);
											//console.log(textStatus);
											//console.log(errorThrown);
											$.toaster({ title: 'ERROR: ', message : textStatus+' '+errorThrown, color:'red'});
											$('#AXYAjaxShopInGameConfirmButtonUse').attr("disabled", false);
											$('#AXYAjaxShopInGameConfirmButtonUse').val("确认");
										},
										complete:function (XMLHttpRequest, textStatus) {
											//console.log(XMLHttpRequest);
											//console.log(textStatus);
											//$.toaster({ title: 'COMPLETE: ', message : textStatus, color:'white'});
											$('#AXYAjaxShopInGameConfirmButtonUse').attr("disabled", false);
											$('#AXYAjaxShopInGameConfirmButtonUse').val("确认");
										}
									});
								});
							});
							
							AXY.AjaxNetStuff.Param.ShopInGameFetchDone = true;
						}
						catch(error){
							console.log(error);
						}
					} else{
						//console.log(data);
						$.toaster({ message : data.info+', ERRORCODE: '+data.error, color:'red'});
					};
				},
				error:function (XMLHttpRequest, textStatus, errorThrown) {
					//console.log(XMLHttpRequest);
					//console.log(textStatus);
					//console.log(errorThrown);
					$.toaster({ title: 'ERROR: ', message : textStatus+' '+errorThrown, color:'red'});
				},
				complete:function (XMLHttpRequest, textStatus) {
					//console.log(XMLHttpRequest);
					//console.log(textStatus);
					//$.toaster({ title: 'COMPLETE: ', message : textStatus, color:'white'});
				}
			});
		},
		hide: function () {
			$('#AXYAjaxShopInGame').stop().animate({"height": "0"}, "normal", function() {
				$(this).hide();
				//$(this).remove();
				$gameSystem.setTouchMoveEnabled(true);
			});
		}
	};
}

//ajax danmu
if(AXY.AjaxNetStuff.Param.EnableDanmu){
	//display html first
	var AXYAjaxDanmuTemplate = 
					'<div class="AXYAjaxDanmu" id="AXYAjaxDanmu">' +
						'<div class="AXYAjaxDanmuBG"></div>' +
						'<input type="button" class="AXYAjaxDanmuButton" id="AXYAjaxDanmuButtonSwitch" value="禁用" />' +
						'<select class="AXYAjaxDanmuButton" id="AXYAjaxDanmuButtonPosition"><option value=1>滚动</option><option value=2>顶部</option><option value=3>中部</option></select>' +
						'<input type="text" class="AXYAjaxDanmuInput" id="AXYAjaxDanmuInput" placeholder="输入弹幕内容" />' +
						'<input type="button" class="AXYAjaxDanmuButton" id="AXYAjaxDanmuButtonUse" value="发送" />' +
						'<input type="button" class="AXYAjaxDanmuButton" id="AXYAjaxDanmuButtonClear" value="清空" />' +
						'<input type="button" class="AXYAjaxDanmuButton" id="AXYAjaxDanmuButtonClose" value="关闭" />' +
						'<input type="color" class="AXYAjaxDanmuButton" id="AXYAjaxDanmuButtonColor" value="#FF0000">' +
						'</div><div class="AXYAjaxDanmuButtonImg"><img src="img/pictures/Arrow4.png" class="AXYAjaxDanmuOpen"></div>';
	var AXYAjaxDanmuStyleCss = 
			'.AXYAjaxDanmu{position:fixed;top:10px;left:.5%;z-index:'+
			(AXY.AjaxNetStuff.Param.zIndex)+';display:none;margin:0 auto;width:98%;height:0px;text-align:center;}'+
			'.AXYAjaxDanmu .AXYAjaxDanmuBG{position:absolute;width:100%;height:100%;border:3px solid #fff;border-radius:10px;background:#000;opacity:.5}'+
			'.AXYAjaxDanmu .AXYAjaxDanmuInput{margin:15px 0 15px 2%;text-align:center;width:30%;height:50px;imeMode:active}'+
			'.AXYAjaxDanmu .AXYAjaxDanmuButton,.AXYAjaxDanmu .AXYAjaxDanmuInput{position:relative;outline:0;border:1px solid #fff;border-radius:5px;background-color:rgba(0,0,0,0.4);color:#fff;font-size:24px;}'+
			'.AXYAjaxDanmu .AXYAjaxDanmuButton{top:0;z-index:10000;margin-left:2%;width:10%;height:50px;cursor:pointer}'+
			'.AXYAjaxDanmuButtonImg{position:fixed;z-index:10000;margin:auto;left:'+
			AXY.AjaxNetStuff.Param.ImgWidth+'px;right:0;top:0;bottom:0;text-align:center;pointer-events:none;}.AXYAjaxDanmuButtonImg img{width:'+
			AXY.AjaxNetStuff.Param.ImgWidth+'px;height:'+
			AXY.AjaxNetStuff.Param.ImgHeight+'px;opacity:'+
			AXY.AjaxNetStuff.Param.ImgOpacity+';pointer-events:auto;}';

	$('body').append(AXYAjaxDanmuTemplate);
	$('#AXYAjaxDanmu').append('<style type="text/css">'+AXYAjaxDanmuStyleCss+'</style>');
	$('#AXYAjaxDanmuButtonPosition').css('display', 'none');
	$('#AXYAjaxDanmuButtonColor').css('display', 'none');

	var AXY_AjaxDanmuURL = AXY.AjaxNetStuff.Param.URL.replace('zhongchou','rmmvgame').replace('product','rmmvgamedanmu');
	//var danmuXpoor = Math.ceil(Graphics.width/96);
	//var danmuYpoor = Math.ceil(Graphics.height/96);
	var danmuXpoor = 10;
	var danmuYpoor = 10;
	var lastid = 0;
	
	//then bind action
	var AXY_AjaxDanmu = {
		show: function () {
			if(!$gameMap){
				$.toaster({ message : '请先进入游戏', color:'white'});
				return;
			}
			if(!$gameMap._mapId){
				$.toaster({ message : '请先进入游戏', color:'white'});
				return;
			}
			/*console.log($gameMap);
			console.log($gameSystem);
			console.log($gameTemp);
			console.log($gameTroop);
			console.log($gamePlayer);
			console.log($gameParty);
			console.log($gameActors);
			console.log($gameScreen);*/
			//console.log($$gameTroop);
			//console.log($$gameTroop);
			//console.log($$gameTroop);
			
			var danmuStartX = $('#UpperCanvas')[0].scrollWidth;
			var danmuStartY = 0;
			var danmuEndX = 0;
			var danmuAid = 0; //auto increament
			if(document.body.scrollWidth > $('#UpperCanvas')[0].scrollWidth){
				danmuStartX += (document.body.scrollWidth - $('#UpperCanvas')[0].scrollWidth) / 2;
				danmuEndX = (document.body.scrollWidth - $('#UpperCanvas')[0].scrollWidth) / 2;
				//console.log(danmuStartX);
			}
			if(document.body.scrollHeight > $('#UpperCanvas')[0].scrollHeight){
				danmuStartY = (document.body.scrollHeight - $('#UpperCanvas')[0].scrollHeight) / 2;
				//console.log(danmuStartY);
			}
			/*AXY_Text.show({id:1, msg:"'hi, world!'", align: 'topleft', x:danmuStartX, y:danmuStartY+100, backgroundcolor:'rgba(0,0,0,0.4)'});
			AXY_Text.show({id:2, msg:"'hi, world'", align: 'topleft', x:danmuStartX-100, y:danmuStartY+200, backgroundcolor:'rgba(0,0,0,0.7)'});
			AXY_Text.show({id:3, msg:"'hi, world'", align: 'topleft', x:danmuStartX-200, y:danmuStartY+300});
			$('#AXYText1').css('left', danmuStartX-$('#AXYText1')[0].clientWidth);
			$('#AXYText1').stop().show().animate({"left": danmuEndX}, 5000, '');
			$('#AXYText2').stop().show().animate({"left": danmuEndX}, 5000, '', function(){AXY_Text.remove(2);});
			$('#AXYText3').stop().show().animate({"left": danmuEndX}, 5000, '', function(){AXY_Text.remove(3);});
			//$('#AXYText2').stop().show().animate({"left": -20});
			//$('#AXYText3').stop().show().animate({"left": -20}, "fast");
			console.log($('#AXYText1'));*/
			
			$('.AXYAjaxDanmuOpen').hide();
			$('#AXYAjaxDanmu').stop().show().animate({"height": "80"}, "normal");
			$gameSystem.setTouchMoveEnabled(false);
			$('#AXYAjaxDanmuInput').focus();
			var css =
			{
				'font-family':	$gameSystem ? Window_Base.prototype.standardFontFace : 'GameFont'
			};
			$('#AXYAjaxDanmuInput').css(css);
			$('.AXYAjaxDanmuButton').css(css);
			
			$('#AXYAjaxDanmuInput').keydown(function (e) {
				if (e.keyCode == 8) {
					var _name = this.value.slice(0, this.value.length - 1);
					this.value = _name;
				}
			}); 
			$('#AXYAjaxDanmuInput').unbind('click touchend').bind('click touchend',function () {
				$('#AXYAjaxDanmuInput').focus();
			}); 
			//console.log($('#AXYAjaxDanmuInput'));
			$('#AXYAjaxDanmuInput').keydown(function (e) {
				if (e.keyCode == 13) {
					$('#AXYAjaxDanmuButtonUse').click();
				}
			}); 
			$('#AXYAjaxDanmuButtonUse').unbind('click touchend').bind('click touchend',function() {
				if(!AXY.AjaxNetStuff.Param.Loggedin){
					$.toaster({ message : '请先登录', color:'white'});
					return;
				}
				
				if(!AXY.AjaxNetStuff.Param.DanmuSwitch){
					$.toaster({ message : '请先启用弹幕', color:'white'});
					return;
				}
				
				if($('#AXYAjaxDanmuButtonUse')[0].disabled){
					//console.log($('#AXYAjaxDanmuButtonUse')[0].disabled);
					return;
				}
				//console.log($('#AXYAjaxDanmuButtonUse'));
				//console.log($('#AXYAjaxDanmuButtonUse')[0].disabled);

				$('#AXYAjaxDanmuButtonUse').attr("disabled", true);
				$('#AXYAjaxDanmuButtonUse').val("sending");
				//console.log($('#AXYAjaxDanmuButtonUse'));
				//console.log(typeof($('#AXYAjaxDanmuButtonUse')[0].disabled));
				//return;
				var inputDanmu = $('#AXYAjaxDanmuInput').val();
				inputDanmu = inputDanmu.replace(/<\/?[^>]*>/gim,"");//去掉所有的html标记
				inputDanmu = inputDanmu.replace(/(^\s+)|(\s+$)/g,"");//去掉前后空格
				inputDanmu = inputDanmu.substr(0,60);//限制长度
				//inputDanmu = inputDanmu.replace(/\s/g,"");//去除文章中间空格
				//console.log($('#AXYAjaxDanmuInput'));
				//console.log($('#AXYAjaxDanmuInput').val());
				//console.log(inputcoupon);
				//console.log(str);
				//console.log(result);
				//console.log(ss);
				
				
				danmuAid++;
				var danmuid = danmuAid;
				var danmuRndY = parseInt(Math.random()*(400-100+1)+100,10);
				//var danmuRndLifetime = parseInt(Math.random()*(8000-3000+1)+3000,10);
				//var danmuRndY = 100;
				//var danmuRndLifetime = 5000;

				if(!inputDanmu){
					//console.log('代码不能为空');
					//$.toaster({ message : '不能为空', color:'red'});
					AXY_Text.show({id:'Error'+danmuid, msg:"'不能为空'", align: 'topleft', x:0, y:0, backgroundcolor:'rgba(0,0,0,0.4)', color:'red'});
					$('#AXYTextError'+danmuid).css({'left':danmuStartX-$('#AXYTextError'+danmuid)[0].clientWidth, 'top':danmuStartY+danmuRndY});
					$('#AXYTextError'+danmuid).stop().show().animate({"left": danmuEndX}, AXY.AjaxNetStuff.Param.DanmuSpeed, '', function(){AXY_Text.remove('Error'+danmuid);});
					$('#AXYAjaxDanmuButtonUse').attr("disabled", false);
					$('#AXYAjaxDanmuButtonUse').val("发送");
					return;
				}
				//$.toaster({ message : $gameActors._data[1]._name+': '+inputDanmu, color:'white'});
				//AXY_Text.show({id:'Error'+danmuid, msg:'"'+$gameActors._data[1]._name+': '+inputDanmu+'"', align: 'topleft', x:0, y:0});
				//$('#AXYTextError'+danmuid).css({'left':danmuStartX-$('#AXYTextError'+danmuid)[0].clientWidth, 'top':danmuStartY+danmuRndY});
				//$('#AXYTextError'+danmuid).stop().show().animate({"left": danmuEndX}, AXY.AjaxNetStuff.Param.DanmuSpeed, '', function(){AXY_Text.remove('Error'+danmuid);});
				$('#AXYAjaxDanmuInput').val('').focus();
				//else{
				
				/*if(!lasttime){
					lasttime = new Date().Format("yyyy-MM-dd hh:mm");
				}*/
				
				/*$gameSystem.onBeforeSave();
				var saveinfo = ((DataManager.makeSavefileInfo()));
				var savedata = ((DataManager.makeSaveContents()));
				console.log(saveinfo);
				console.log(savedata);*/
				//console.log($gameMap);
				//console.log($gameSystem);
				//console.log($gameInfo);
				
				if($gameTroop._inBattle){
					$.ajax({
						url: AXY_AjaxDanmuURL,
						type: 'POST',
						dataType: 'json',
						data: {sid: AXY.AjaxNetStuff.Param.sid, danmumsg: inputDanmu, mapid: $gameMap._mapId, displayx: $gamePlayer._x, displayy: $gamePlayer._y, steps: $gameParty._steps, actorname: $gameActors._data[1]._name, playtime: parseInt(Graphics.frameCount/60), troopid: $gameTroop._troopId},
						success: function (data) {
							//console.log(data);
							if (data.status) {
								//console.log(data);
							} else{
								//console.log(data);
								//$.toaster({ message : data.info+', ERRORCODE: '+data.error, color:'red'});
							};
							$('#AXYAjaxDanmuButtonUse').attr("disabled", false);
							$('#AXYAjaxDanmuButtonUse').val("发送");
						},
						error:function (XMLHttpRequest, textStatus, errorThrown) {
							//console.log(XMLHttpRequest);
							//console.log(textStatus);
							//console.log(errorThrown);
							$.toaster({ title: 'ERROR: ', message : textStatus+' '+errorThrown, color:'red'});
							$('#AXYAjaxDanmuButtonUse').attr("disabled", false);
							$('#AXYAjaxDanmuButtonUse').val("发送");
						},
						complete:function (XMLHttpRequest, textStatus) {
							//console.log(XMLHttpRequest);
							//console.log(textStatus);
							//$.toaster({ title: 'COMPLETE: ', message : textStatus, color:'white'});
							$('#AXYAjaxDanmuButtonUse').attr("disabled", false);
							$('#AXYAjaxDanmuButtonUse').val("发送");
						}
					});
				}else if($gameMap._mapId){
					$.ajax({
						url: AXY_AjaxDanmuURL,
						type: 'POST',
						dataType: 'json',
						data: {sid: AXY.AjaxNetStuff.Param.sid, danmumsg: inputDanmu, mapid: $gameMap._mapId, displayx: $gamePlayer._x, displayy: $gamePlayer._y, steps: $gameParty._steps, actorname: $gameActors._data[1]._name, playtime: parseInt(Graphics.frameCount/60), troopid: 0},
						success: function (data) {
							//console.log(data);
							if (data.status) {
								//console.log(data);
							} else{
								//console.log(data);
								//$.toaster({ message : data.info+', ERRORCODE: '+data.error, color:'red'});
							};
							$('#AXYAjaxDanmuButtonUse').attr("disabled", false);
							$('#AXYAjaxDanmuButtonUse').val("发送");
						},
						error:function (XMLHttpRequest, textStatus, errorThrown) {
							//console.log(XMLHttpRequest);
							//console.log(textStatus);
							//console.log(errorThrown);
							$.toaster({ title: 'ERROR: ', message : textStatus+' '+errorThrown, color:'red'});
							$('#AXYAjaxDanmuButtonUse').attr("disabled", false);
							$('#AXYAjaxDanmuButtonUse').val("发送");
						},
						complete:function (XMLHttpRequest, textStatus) {
							//console.log(XMLHttpRequest);
							//console.log(textStatus);
							//$.toaster({ title: 'COMPLETE: ', message : textStatus, color:'white'});
							$('#AXYAjaxDanmuButtonUse').attr("disabled", false);
							$('#AXYAjaxDanmuButtonUse').val("发送");
						}
					});
				}
				//}
			});
			$('#AXYAjaxDanmuButtonClear').unbind('click touchstart').bind('click touchstart',function() {
				$('#AXYAjaxDanmuInput').val('').focus();
			});
			$('#AXYAjaxDanmuButtonClose').unbind('click touchstart').bind('click touchstart',function() {
				AXY_AjaxDanmu.hide();
			});
			$('#AXYAjaxDanmuButtonSwitch').unbind('click touchstart').bind('click touchstart',function() {
				if(AXY.AjaxNetStuff.Param.DanmuSwitch){
					$('#AXYAjaxDanmuButtonSwitch').val("启用");
					AXY.AjaxNetStuff.Param.DanmuSwitch = false;
				}else{
					$('#AXYAjaxDanmuButtonSwitch').val("禁用");
					AXY.AjaxNetStuff.Param.DanmuSwitch = true;
				}
			});
		},
		hide: function () {
			$('#AXYAjaxDanmu').stop().animate({"height": "0"}, "normal", function() {
				$(this).hide();
				//$(this).remove();
				$gameSystem.setTouchMoveEnabled(true);
				$('.AXYAjaxDanmuOpen').show();
			});
		}
	};
	
	//last bind the click
	$('.AXYAjaxDanmuOpen').unbind('click touchend').bind('click touchend',function () {
		AXY_AjaxDanmu.show();
	});
	
	//auto fetch danmu
	
		try{var i=0;
		setInterval(function(){
			//test
			//AXY.AjaxNetStuff.Param.DanmuObj.Map.push(1);
			/*if(!AXY.AjaxNetStuff.Param.DanmuObj.Map[i]){
			AXY.AjaxNetStuff.Param.DanmuObj.Map[i] = [];
			
			}
			AXY.AjaxNetStuff.Param.DanmuObj.Map[i][1] = i;
			AXY.AjaxNetStuff.Param.DanmuObj.Map[i][2] = i;
			//AXY.AjaxNetStuff.Param.DanmuObj.Map.push(1);
			//AXY.AjaxNetStuff.Param.DanmuObj.Map[i] = [];
			//AXY.AjaxNetStuff.Param.DanmuObj.Map[2][1] = 1;
			//AXY.AjaxNetStuff.Param.DanmuObj.Map[i][3] = 3;
			//console.log(obj[index].id);
			console.log(AXY.AjaxNetStuff.Param.DanmuObj.Map);
			i++;
			return;*/
			//test end
			
			
			if(AXY.AjaxNetStuff.Param.DanmuSwitch == false){
				return;
			}
			if(!$gameMap){
				return;
			}
			if(!$gameMap._mapId){
				return;
			}
			/*if(!$gameMap._axydanmu){
				$gameMap._axydanmu = [];
			}*/
			
			var danmuStartX = $('#UpperCanvas')[0].scrollWidth;
			var danmuStartY = 0;
			var danmuEndX = 0;

			if(document.body.scrollWidth > $('#UpperCanvas')[0].scrollWidth){
				danmuStartX += (document.body.scrollWidth - $('#UpperCanvas')[0].scrollWidth) / 2;
				danmuEndX = (document.body.scrollWidth - $('#UpperCanvas')[0].scrollWidth) / 2;
				console.log(danmuStartX);
			}
			if(document.body.scrollHeight > $('#UpperCanvas')[0].scrollHeight){
				danmuStartY = (document.body.scrollHeight - $('#UpperCanvas')[0].scrollHeight) / 2;
				console.log(danmuStartY);
			}

			
			//var danmuRndY = 100;
			//var danmuRndLifetime = 3000;

			
			/*if(!lasttime){
				lasttime = new Date().Format("yyyy-MM-dd hh:mm");
			}*/
			
			/*$gameSystem.onBeforeSave();
			var saveinfo = ((DataManager.makeSavefileInfo()));
			var savedata = ((DataManager.makeSaveContents()));
			console.log(saveinfo);
			console.log(savedata);*/
			
			//console.log($gameMap);
			//console.log($gameSystem);
			//console.log($gameTroop);
			//console.log({mapid: $gameMap._mapId, displayxmin: $gameMap._displayX-danmuXpoor, displayymin: $gameMap._displayY-danmuYpoor, displayxmax: $gameMap._displayX+danmuXpoor, displayymax: $gameMap._displayY+danmuYpoor, steps: $gameParty._steps, playtime: parseInt(Graphics.frameCount/60), lastid: lastid});
			if($gameTroop._inBattle){
				var gameTroop_troopId = $gameTroop._troopId;
				if(!AXY.AjaxNetStuff.Param.DanmuObj.Troop[gameTroop_troopId]){
					//AXY.AjaxNetStuff.Param.DanmuObj.Troop.push($gameTroop._troopId);
					AXY.AjaxNetStuff.Param.DanmuObj.Troop[gameTroop_troopId] = 1;
				}
				//console.log(AXY.AjaxNetStuff.Param.DanmuObj);
				$.ajax({
					url: AXY_AjaxDanmuURL,
					type: 'POST',
					dataType: 'json',
					data: {troopid: gameTroop_troopId, lastid: AXY.AjaxNetStuff.Param.DanmuObj.Troop[gameTroop_troopId]},
					success: function (data) {
						//console.log(data);
						if (data.status) {
							var obj = data.jsonstr;
							//console.log(obj);
							$.each(obj, function(index) {
								//console.log(obj[index]);
								
								//$gameMap._axydanmu.push(obj[index]);
								
								setTimeout(function(){
									var danmuRndY = parseInt(Math.random()*(400-100+1)+100,10);
									//var danmuRndLifetime = parseInt(Math.random()*(8000-3000+1)+3000,10);
									var time = new Date((obj[index].timeline).replace(new RegExp("-","gm"),"/")).Format("hhmm");
									//$.toaster({ message : obj[index].actorname+'['+time+']: '+obj[index].danmumsg, color:'white'});
									var id = 'danmu'+obj[index].id;
									AXY_Text.show({id:id, msg:'"'+obj[index].danmumsg+'"', align:'topleft', x:0, y:0});
									$('#AXYText'+id).css({'left':danmuStartX-$('#AXYText'+id)[0].clientWidth, 'top':danmuStartY+danmuRndY});
									$('#AXYText'+id).stop().show().animate({"left": danmuEndX}, AXY.AjaxNetStuff.Param.DanmuSpeed, '', function(){AXY_Text.remove(id);});
								}, AXY.AjaxNetStuff.Param.DanmuInterval*index);
							});
							//console.log(AXY.AjaxNetStuff.Param.DanmuObj);
							//console.log($gameMap);
							//obj.reverse();
							//lastid = obj[0].id;
							AXY.AjaxNetStuff.Param.DanmuObj.Troop[gameTroop_troopId] = obj[obj.length-1].id;
							
						} else{
							//console.log(data);
							//$.toaster({ message : data.info+', ERRORCODE: '+data.error, color:'red'});
						};
					},
					error:function (XMLHttpRequest, textStatus, errorThrown) {
						//console.log(XMLHttpRequest);
						//console.log(textStatus);
						//console.log(errorThrown);
						//$.toaster({ title: 'ERROR: ', message : textStatus+' '+errorThrown, color:'red'});
					},
					complete:function (XMLHttpRequest, textStatus) {
						//console.log(XMLHttpRequest);
						//console.log(textStatus);
						//$.toaster({ title: 'COMPLETE: ', message : textStatus, color:'white'});
					}
				});
			}else if($gameMap._mapId){
				//console.log($gameMap);
				//console.log($gameMap._mapId);
				var gameMap_mapId = $gameMap._mapId;
				if(!AXY.AjaxNetStuff.Param.DanmuObj.Map[gameMap_mapId]){
					//AXY.AjaxNetStuff.Param.DanmuObj.Map.push($gameMap._mapId);
					AXY.AjaxNetStuff.Param.DanmuObj.Map[gameMap_mapId] = [];
					AXY.AjaxNetStuff.Param.DanmuObj.Map[gameMap_mapId][1] = 1;
				}
				//console.log(AXY.AjaxNetStuff.Param.DanmuObj);
				//try{console.log(AXY.AjaxNetStuff.Param.DanmuObj.Map[gameMap_mapId].join());}catch(e){console.log(e);}
				//try{console.log(AXY.AjaxNetStuff.Param.DanmuObj.Map[gameMap_mapId].join().match(/\d+/g).join());}catch(e){console.log(e);}
				$.ajax({
					url: AXY_AjaxDanmuURL,
					type: 'POST',
					dataType: 'json',
					data: {mapid: $gameMap._mapId, displayxmin: $gamePlayer._x-danmuXpoor, displayymin: $gamePlayer._y-danmuYpoor, displayxmax: $gamePlayer._x+danmuXpoor, displayymax: $gamePlayer._y+danmuYpoor, steps: $gameParty._steps, playtime: parseInt(Graphics.frameCount/60), usedid: AXY.AjaxNetStuff.Param.DanmuObj.Map[gameMap_mapId].join().match(/\d+/g).join()},
					success: function (data) {
						//console.log(data);
						if (data.status) {
							var obj = data.jsonstr;
							//console.log(obj);
							$.each(obj, function(index) {
								//console.log(obj[index]);
								//AXY.AjaxNetStuff.Param.DanmuObj.push(obj[index]);
								//$gameMap._axydanmu.push(obj[index]);
								AXY.AjaxNetStuff.Param.DanmuObj.Map[gameMap_mapId][obj[index].id] = obj[index].id;
								//console.log(obj[index].id);
								//console.log(AXY.AjaxNetStuff.Param.DanmuObj.Map[gameMap_mapId][obj[index].id]);
								
								setTimeout(function(){
									var danmuRndY = parseInt(Math.random()*(400-100+1)+100,10);
									//var danmuRndLifetime = parseInt(Math.random()*(8000-3000+1)+3000,10);
									var time = new Date((obj[index].timeline).replace(new RegExp("-","gm"),"/")).Format("hh:mm");
									//$.toaster({ message : obj[index].actorname+'['+time+']: '+obj[index].danmumsg, color:'white'});
									var id = 'danmu'+obj[index].id;
									//AXY_Text.show({id:id, msg:'"'+obj[index].actorname+'['+time+']: '+obj[index].danmumsg+'"', align:'topleft', x:0, y:0});
									AXY_Text.show({id:id, msg:'"'+obj[index].danmumsg+'"', align:'topleft', x:0, y:0});
									$('#AXYText'+id).css({'left':danmuStartX-$('#AXYText'+id)[0].clientWidth, 'top':danmuStartY+danmuRndY});
									$('#AXYText'+id).stop().show().animate({"left": danmuEndX}, AXY.AjaxNetStuff.Param.DanmuSpeed, '', function(){AXY_Text.remove(id);});
								}, AXY.AjaxNetStuff.Param.DanmuInterval*index);
							});
							
							//console.log($gameMap);
							//obj.reverse();
							//console.log(AXY.AjaxNetStuff.Param.DanmuObj.Map[$gameMap._mapId].join().match(/\d+/g).join());
							//console.log(AXY.AjaxNetStuff.Param.DanmuObj);
							
						} else{
							//console.log(data);
							//$.toaster({ message : data.info+', ERRORCODE: '+data.error, color:'red'});
						};
					},
					error:function (XMLHttpRequest, textStatus, errorThrown) {
						//console.log(XMLHttpRequest);
						//console.log(textStatus);
						//console.log(errorThrown);
						//$.toaster({ title: 'ERROR: ', message : textStatus+' '+errorThrown, color:'red'});
					},
					complete:function (XMLHttpRequest, textStatus) {
						//console.log(XMLHttpRequest);
						//console.log(textStatus);
						//$.toaster({ title: 'COMPLETE: ', message : textStatus, color:'white'});
					}
				});
			}
		}, 30000);
		}
		catch(e){
			console.log(e);
		}
}

//ajax chat
if(AXY.AjaxNetStuff.Param.EnableChat){
	try{
	//display html first
	var AXYAjaxChatTemplate = 
					'<div class="AXYAjaxChat" id="AXYAjaxChat">' +
						'<div class="AXYAjaxChatBG"></div>' +
						'<input type="text" class="AXYAjaxChatInput" id="AXYAjaxChatInput" placeholder="输入聊天内容" />' +
						'<input type="button" class="AXYAjaxChatButton" id="AXYAjaxChatButtonUse" value="发送" />' +
						'<input type="button" class="AXYAjaxChatButton" id="AXYAjaxChatButtonClear" value="清空" />' +
						'<input type="button" class="AXYAjaxChatButton" id="AXYAjaxChatButtonClose" value="关闭" />' +
					'</div><div class="AXYAjaxChatButtonImg"><img src="img/pictures/Arrow6.png" class="AXYAjaxChatOpen"></div>';
	var AXYAjaxChatStyleCss = 
			'.AXYAjaxChat{position:fixed;top:10px;left:.5%;z-index:'+
			(AXY.AjaxNetStuff.Param.zIndex)+';display:none;margin:0 auto;width:98%;height:0px;text-align:center;}'+
			'.AXYAjaxChat .AXYAjaxChatBG{position:absolute;width:100%;height:100%;border:3px solid #fff;border-radius:10px;background:#000;opacity:.5}'+
			'.AXYAjaxChat .AXYAjaxChatInput{margin:15px 0;text-align:center;width:30%;height:50px;imeMode:active}'+
			'.AXYAjaxChat .AXYAjaxChatButton,.AXYAjaxChat .AXYAjaxChatInput{position:relative;outline:0;border:1px solid #fff;border-radius:5px;background-color:rgba(0,0,0,0.4);color:#fff;font-size:24px;}'+
			'.AXYAjaxChat .AXYAjaxChatButton{top:0;z-index:10000;margin-left:2%;width:10%;height:3pc;cursor:pointer}'+
			'.AXYAjaxChatButtonImg{position:fixed;z-index:10000;margin:auto;left:-'+
			AXY.AjaxNetStuff.Param.ImgWidth+'px;right:0;top:0;bottom:0;text-align:center;pointer-events:none;}.AXYAjaxChatButtonImg img{width:'+
			AXY.AjaxNetStuff.Param.ImgWidth+'px;height:'+
			AXY.AjaxNetStuff.Param.ImgHeight+'px;opacity:'+
			AXY.AjaxNetStuff.Param.ImgOpacity+';pointer-events:auto;}';

	$('body').append(AXYAjaxChatTemplate);
	$('#AXYAjaxChat').append('<style type="text/css">'+AXYAjaxChatStyleCss+'</style>');
	
	var AXY_AjaxChatURL = AXY.AjaxNetStuff.Param.URL.replace('zhongchou','rmmvgame').replace('product','rmmvgamechat');
	var lasttime;
	
	//then bind action
	var AXY_AjaxChat = {
		show: function () {
			if(!AXY.AjaxNetStuff.Param.Loggedin){
				$.toaster({ message : '请先登录', color:'white'});
				return;
			}
			
			$('.AXYAjaxChatOpen').hide();
			$('#AXYAjaxChat').stop().show().animate({"height": "80"}, "normal");
			$gameSystem.setTouchMoveEnabled(false);
			$('#AXYAjaxChatInput').focus();
			var css =
			{
				'font-family':	$gameSystem ? Window_Base.prototype.standardFontFace : 'GameFont'
			};
			$('#AXYAjaxChatInput').css(css);
			$('.AXYAjaxChatButton').css(css);
			
			$('#AXYAjaxChatInput').keydown(function (e) {
				if (e.keyCode == 8) {
					var _name = this.value.slice(0, this.value.length - 1);
					this.value = _name;
				}
			}); 
			$('#AXYAjaxChatInput').unbind('click touchend').bind('click touchend',function () {
				$('#AXYAjaxChatInput').focus();
			}); 
			//console.log($('#AXYAjaxChatInput'));
			$('#AXYAjaxChatInput').keydown(function (e) {
				if (e.keyCode == 13) {
					$('#AXYAjaxChatButtonUse').click();
				}
			}); 
			$('#AXYAjaxChatButtonUse').unbind('click touchend').bind('click touchend',function() {
				if($('#AXYAjaxChatButtonUse')[0].disabled){
					//console.log($('#AXYAjaxChatButtonUse')[0].disabled);
					return;
				}
				//console.log($('#AXYAjaxChatButtonUse'));
				//console.log($('#AXYAjaxChatButtonUse')[0].disabled);

				$('#AXYAjaxChatButtonUse').attr("disabled", true);
				$('#AXYAjaxChatButtonUse').val("sending");
				//console.log($('#AXYAjaxChatButtonUse'));
				//console.log(typeof($('#AXYAjaxChatButtonUse')[0].disabled));
				//return;
				var inputchat = $('#AXYAjaxChatInput').val();
				inputchat = inputchat.replace(/<\/?[^>]*>/gim,"");//去掉所有的html标记
				inputchat = inputchat.replace(/(^\s+)|(\s+$)/g,"");//去掉前后空格
				inputchat = inputchat.substr(0,20);//限制长度
				//inputchat = inputchat.replace(/\s/g,"");//去除文章中间空格
				//console.log($('#AXYAjaxChatInput'));
				//console.log($('#AXYAjaxChatInput').val());
				//console.log(inputcoupon);
				//console.log(str);
				//console.log(result);
				//console.log(ss);


				if(!inputchat){
					//console.log('代码不能为空');
					$.toaster({ message : '不能为空', color:'red'});
					$('#AXYAjaxChatButtonUse').attr("disabled", false);
					$('#AXYAjaxChatButtonUse').val("发送");
					return;
				}
				$.toaster({ message : $gameActors._data[1]._name+': '+inputchat, color:'white'});
				$('#AXYAjaxChatInput').val('').focus();
				//else{
				
				if(!lasttime){
					lasttime = new Date().Format("yyyy-MM-dd hh:mm");
				}
				
				$.ajax({
					url: AXY_AjaxChatURL,
					type: 'POST',
					dataType: 'json',
					data: {sid: AXY.AjaxNetStuff.Param.sid, chatmsg: inputchat, actorname: $gameActors._data[1]._name, lasttime: lasttime},
					success: function (data) {
						//console.log(data);
						if (data.status) {
							var obj = data.jsonstr;
							lasttime = obj[0].timeline;
							obj.reverse();
							//console.log(obj);
							$.each(obj, function(index) {
								//console.log(obj[index]);
								var time = new Date((obj[index].timeline).replace(new RegExp("-","gm"),"/")).Format("hh:mm");
								$.toaster({ message : obj[index].actorname+'['+time+']: '+obj[index].chatmsg, color:'white'});
							});
						} else{
							//console.log(data);
							//$.toaster({ message : data.info+', ERRORCODE: '+data.error, color:'red'});
						};
						$('#AXYAjaxChatButtonUse').attr("disabled", false);
						$('#AXYAjaxChatButtonUse').val("发送");
					},
					error:function (XMLHttpRequest, textStatus, errorThrown) {
						//console.log(XMLHttpRequest);
						//console.log(textStatus);
						//console.log(errorThrown);
						$.toaster({ title: 'ERROR: ', message : textStatus+' '+errorThrown, color:'red'});
						$('#AXYAjaxChatButtonUse').attr("disabled", false);
						$('#AXYAjaxChatButtonUse').val("发送");
					},
					complete:function (XMLHttpRequest, textStatus) {
						//console.log(XMLHttpRequest);
						//console.log(textStatus);
						//$.toaster({ title: 'COMPLETE: ', message : textStatus, color:'white'});
						$('#AXYAjaxChatButtonUse').attr("disabled", false);
						$('#AXYAjaxChatButtonUse').val("发送");
					}
				});
				//}
			});
			$('#AXYAjaxChatButtonClear').unbind('click touchstart').bind('click touchstart',function() {
				$('#AXYAjaxChatInput').val('').focus();
			});
			$('#AXYAjaxChatButtonClose').unbind('click touchstart').bind('click touchstart',function() {
				AXY_AjaxChat.hide();
			});
		},
		hide: function () {
			$('#AXYAjaxChat').stop().animate({"height": "0"}, "normal", function() {
				$(this).hide();
				//$(this).remove();
				$gameSystem.setTouchMoveEnabled(true);
				$('.AXYAjaxChatOpen').show();
			});
		}
	};
	//last bind the click
	$('.AXYAjaxChatOpen').unbind('click touchend').bind('click touchend',function () {
		AXY_AjaxChat.show();
	});
	
	//auto fetch chat
	setInterval(function(){
		if(!$gameParty){
			return;
		}
		if(!AXY.AjaxNetStuff.Param.Loggedin){
			return;
		}
		if(!lasttime){
			lasttime = new Date().Format("yyyy-MM-dd hh:mm:ss");
		}
		//console.log(lasttime);

		$.ajax({
			url: AXY_AjaxChatURL,
			type: 'POST',
			dataType: 'json',
			data: {sid: AXY.AjaxNetStuff.Param.sid, chatmsg: '', actorname: '', lasttime: lasttime},
			success: function (data) {
				//console.log(data);
				if (data.status) {
					var obj = data.jsonstr;
					lasttime = obj[0].timeline;
					obj.reverse();
					//console.log(obj);
					$.each(obj, function(index) {
						//console.log(obj[index]);
						var time = new Date((obj[index].timeline).replace(new RegExp("-","gm"),"/")).Format("hh:mm");
						$.toaster({ message : obj[index].actorname+'['+time+']: '+obj[index].chatmsg, color:'white'});
					});
				} else{
					//console.log(data);
					//$.toaster({ message : data.info+', ERRORCODE: '+data.error, color:'red'});
					lasttime = new Date().Format("yyyy-MM-dd hh:mm:ss");
				};
				$('#AXYAjaxChatButtonUse').attr("disabled", false);
				$('#AXYAjaxChatButtonUse').val("发送");
			},
			error:function (XMLHttpRequest, textStatus, errorThrown) {
				//console.log(XMLHttpRequest);
				//console.log(textStatus);
				//console.log(errorThrown);
				//$.toaster({ title: 'ERROR: ', message : textStatus+' '+errorThrown, color:'red'});
				$('#AXYAjaxChatButtonUse').attr("disabled", false);
				$('#AXYAjaxChatButtonUse').val("发送");
			},
			complete:function (XMLHttpRequest, textStatus) {
				//console.log(XMLHttpRequest);
				//console.log(textStatus);
				//$.toaster({ title: 'COMPLETE: ', message : textStatus, color:'white'});
				$('#AXYAjaxChatButtonUse').attr("disabled", false);
				$('#AXYAjaxChatButtonUse').val("发送");
				//var time = new Date().Format("hh:mm")
				//$.toaster({ message : $gameActors._data[1]._name+'['+time+']: '+inputchat, color:'white', fontsize: 12});
			}
		});
	}, 30000);
	}
	catch(e){
		console.log(e);
	}
}

//ajax cloud save
if (AXY.AjaxNetStuff.Param.EnableCloudSave) {
	//=============================================================================
	// ** Window MenuCommand
	//=============================================================================	

	//==============================
	// * make Command List
	//==============================
	AXY.AjaxNetStuff.Alias.addOriginalCommandsCloudSave = Window_MenuCommand.prototype.addOriginalCommands;
	Window_MenuCommand.prototype.addOriginalCommands = function() {
		AXY.AjaxNetStuff.Alias.addOriginalCommandsCloudSave.call(this);
		this.addCommand(AXY.AjaxNetStuff.Param.CloudSaveText, 'cloud_save', true);
	};
		
	//=============================================================================
	// ** Scene Menu
	//=============================================================================	

	//==============================
	// * create Command Window
	//==============================
	AXY.AjaxNetStuff.Alias.createCommandWindowCloudSave = Scene_Menu.prototype.createCommandWindow;
	Scene_Menu.prototype.createCommandWindow = function() {
		AXY.AjaxNetStuff.Alias.createCommandWindowCloudSave.call(this); 
		this._commandWindow.setHandler('cloud_save',      this.commandCloudSave.bind(this));
		/*if (Imported.MOG_TimeSystem && Moghunter.timeWindow_menu) {	
			this._commandWindow.height -= this._commandWindow.itemHeight();
		};*/
	};

	//==============================
	// * Cloud Save
	//==============================
	Scene_Menu.prototype.commandCloudSave = function() {
		AXY_AjaxCloudSave.show();
		// Close option window
		SceneManager.pop();	
	};
}

var AXY_AjaxCloudSave = {
	show: function () {
		if(!AXY.AjaxNetStuff.Param.Loggedin){
			$.toaster({ message : '请先登录', color:'white'});
			return;
		}
		
		var AXYAjaxCloudSaveTemplate = 
				'<div class="AXYAjaxCloudSave" id="AXYAjaxCloudSave">' +
					'<div class="AXYAjaxCloudSaveBG"></div>' +
					'<input type="button" class="AXYAjaxCloudSaveButton" id="AXYAjaxCloudSaveButtonUse" value="保存" />' +
					'<input type="button" class="AXYAjaxCloudSaveButton" id="AXYAjaxCloudSaveButtonClear" value="读取" />' +
					'<input type="button" class="AXYAjaxCloudSaveButton" id="AXYAjaxCloudSaveButtonClose" value="关闭" />' +
				'</div>';
		var AXYAjaxCloudSaveStyleCss = 
				'.AXYAjaxCloudSave{position:fixed;top:10px;left:.5%;z-index:10000;display:none;margin:0 auto;width:0%;height:80px;text-align:center;}'+
				'.AXYAjaxCloudSave .AXYAjaxCloudSaveBG{position:absolute;width:100%;height:100%;border:3px solid #fff;border-radius:10px;background:#000;opacity:.5}'+
				'.AXYAjaxCloudSave .AXYAjaxCloudSaveButton{margin:15px 0;text-align:center;width:30%;height:50px;imeMode:active}'+
				'.AXYAjaxCloudSave .AXYAjaxCloudSaveButton,.AXYAjaxCloudSave .AXYAjaxCloudSaveInput{position:relative;outline:0;border:1px solid #fff;border-radius:5px;background-color:rgba(0,0,0,0.4);color:#fff;font-size:24px;}'+
				'.AXYAjaxCloudSave .AXYAjaxCloudSaveButton{top:0;z-index:10000;margin-left:2%;width:10%;height:3pc;word-spacing:20px;cursor:pointer}';
		var css =
				{
					'font-family':	$gameSystem ? Window_Base.prototype.standardFontFace : 'GameFont'
				};
		$('body').append(AXYAjaxCloudSaveTemplate);
		$('#AXYAjaxCloudSave').append('<style type="text/css">'+AXYAjaxCloudSaveStyleCss+'</style>');
		$('.AXYAjaxCloudSaveButton').css(css);
		//console.log(css);
		//console.log($gameParty);
		//console.log($gameSystem);
		//console.log(TextManager.currencyUnit);

		$('#AXYAjaxCloudSave').stop().show().animate({"width": "98%"}, "normal");
		$gameSystem.setTouchMoveEnabled(false);
		
		//save button
		$('#AXYAjaxCloudSaveButtonUse').unbind('click touchend').bind('click touchend',function() {
			AXY_AjaxCloudSave.hide();
			/*if($('#AXYAjaxCloudSaveButtonUse')[0].disabled){
				//console.log($('#AXYAjaxCloudSaveButtonUse')[0].disabled);
				return;
			}*/
			//console.log($('#AXYAjaxCloudSaveButtonUse'));
			//console.log($('#AXYAjaxCloudSaveButtonUse')[0].disabled);

			//$('#AXYAjaxCloudSaveButtonUse').attr("disabled", true);
			//$('#AXYAjaxCloudSaveButtonUse').val("saving");
			//console.log($('#AXYAjaxCloudSaveButtonUse'));
			//console.log(AXY.AjaxNetStuff.Param.sid);
			//alert(AXY.AjaxNetStuff.Param.sid);

			$gameSystem.onBeforeSave();
			var saveinfo = LZString.compressToBase64(JsonEx.stringify(DataManager.makeSavefileInfo()));
			var savedata = LZString.compressToBase64(JsonEx.stringify(DataManager.makeSaveContents()));
			//console.log(saveinfo);
			//console.log(savedata);
			if (savedata.length >= 200000) {
				console.log("Save data too big");
			};
		
			$.toaster({ message : '正在保存至云端...', color:'white'});
			var AXY_AjaxCloudSaveURL = AXY.AjaxNetStuff.Param.URL.replace('zhongchou','rmmvgame').replace('product','rmmvgamecloudsave');
			$.ajax({
				url: AXY_AjaxCloudSaveURL,
				type: 'POST',
				dataType: 'json',
				data: {sid: AXY.AjaxNetStuff.Param.sid, saveinfo: saveinfo, savedata: savedata},
				success: function (data) {
					//console.log(data);
					//alert(data.sid);
					//alert(data.uid);
					//alert(data.ssid);
					if (data.status) {
						$.toaster({ message : "保存成功！"});
						setTimeout(function(){
							$.toaster({ message : "云端存储成本较高，众筹游戏《"+data.gamename+"》诚邀您参与众筹！"});
						}, 3000);
					} else{
						//console.log(data);
						$.toaster({ message : data.info+', ERRORCODE: '+data.error, color:'red'});
					};
					//$('#AXYAjaxCloudSaveButtonUse').attr("disabled", false);
					//$('#AXYAjaxCloudSaveButtonUse').val("保存");
				},
				error:function (XMLHttpRequest, textStatus, errorThrown) {
					console.log(XMLHttpRequest);
					console.log(textStatus);
					console.log(errorThrown);
					$.toaster({ title: 'ERROR: ', message : textStatus+' '+errorThrown, color:'red'});
					//$('#AXYAjaxCloudSaveButtonUse').attr("disabled", false);
					//$('#AXYAjaxCloudSaveButtonUse').val("保存");
				},
				complete:function (XMLHttpRequest, textStatus) {
					console.log(XMLHttpRequest);
					console.log(textStatus);
					$.toaster({ title: 'COMPLETE: ', message : textStatus, color:'gray'});
					//$('#AXYAjaxCloudSaveButtonUse').attr("disabled", false);
					//$('#AXYAjaxCloudSaveButtonUse').val("保存");
				}
			});
		});
		
		//load button
		$('#AXYAjaxCloudSaveButtonClear').unbind('click touchstart').bind('click touchstart',function() {
			AXY_AjaxCloudSave.hide();
			$.toaster({ message : '返回标题页面，请勿操作...', color:'white'});
			SceneManager.push(Scene_Title);

			/*if($('#AXYAjaxCloudSaveButtonClear')[0].disabled){
				//console.log($('#AXYAjaxCloudSaveButtonUse')[0].disabled);
				return;
			}*/
			//console.log($('#AXYAjaxCloudSaveButtonUse'));
			//console.log($('#AXYAjaxCloudSaveButtonUse')[0].disabled);

			//$('#AXYAjaxCloudSaveButtonClear').attr("disabled", true);
			//$('#AXYAjaxCloudSaveButtonClear').val("loading");

			setTimeout(function()
			{
				$.toaster({ message : '正在从云端读取...', color:'white'});
				var AXY_AjaxCloudLoadURL = AXY.AjaxNetStuff.Param.URL.replace('zhongchou','rmmvgame').replace('product','rmmvgamecloudload');
				$.ajax({
					url: AXY_AjaxCloudLoadURL,
					type: 'POST',
					dataType: 'json',
					data: {sid: AXY.AjaxNetStuff.Param.sid},
					success: function (data) {
						//console.log(data);
						if (data.status) {
							try{
							$.toaster({ message : "读取成功！"});
							
							// Extract data from savegame
							console.log("Extract save contents");
							DataManager.createGameObjects();
							DataManager.extractSaveContents(JsonEx.parse(LZString.decompressFromBase64(data.savedata)));
							//console.log(LZString.decompressFromBase64(data.savedata));
							//console.log(JsonEx.parse(LZString.decompressFromBase64(data.savedata)));

							// Move player
							console.log("Reserve transfer player");
							$gamePlayer.reserveTransfer($gameMap.mapId(), $gamePlayer.x, $gamePlayer.y);
							$gamePlayer.requestMapReload();

							// Initialize map
							console.log("Goto Scene_Map");
							$gameSystem.onAfterLoad();
							Scene_Load.prototype.reloadMapIfUpdated.call(null);
							SceneManager.goto(Scene_Map);
							if (SceneManager._scene) { 
								SceneManager._scene.fadeOutAll(); 
							};

							/*
							//exec common event
							if (PROPERTY.GAME.AFTERLOADEVENT!=0) {
								debug(LOGGING.ALL,"reserveCommonEvent: "+PROPERTY.GAME.AFTERLOADEVENT);
								$gameTemp.reserveCommonEvent(PROPERTY.GAME.AFTERLOADEVENT);
							};*/

							setTimeout(function(){
								$.toaster({ message : "云端存储成本较高，众筹游戏《"+data.gamename+"》诚邀您参与众筹！"});
								$gameSystem.setTouchMoveEnabled(true);
							}, 3000);
							}
							catch(e){
								console.log(e);
							}
						} else{
							console.log(data);
							$.toaster({ message : data.info+', ERRORCODE: '+data.error, color:'red'});
						};
						//$('#AXYAjaxCloudSaveButtonClear').attr("disabled", false);
						//$('#AXYAjaxCloudSaveButtonClear').val("读取");
					},
					error:function (XMLHttpRequest, textStatus, errorThrown) {
						console.log(XMLHttpRequest);
						console.log(textStatus);
						console.log(errorThrown);
						$.toaster({ title: 'ERROR: ', message : textStatus+' '+errorThrown, color:'red'});
						//$('#AXYAjaxCloudSaveButtonClear').attr("disabled", false);
						//$('#AXYAjaxCloudSaveButtonClear').val("读取");
					},
					complete:function (XMLHttpRequest, textStatus) {
						console.log(XMLHttpRequest);
						console.log(textStatus);
						$.toaster({ title: 'COMPLETE: ', message : textStatus, color:'gray'});
						//$('#AXYAjaxCloudSaveButtonClear').attr("disabled", false);
						//$('#AXYAjaxCloudSaveButtonClear').val("读取");
					}
				});
			}, 3000);
		});
		
		//close button
		$('#AXYAjaxCloudSaveButtonClose').unbind('click touchstart').bind('click touchstart',function() {
			AXY_AjaxCloudSave.hide();
		});
	},
	hide: function () {
		$('#AXYAjaxCloudSave').stop().animate({"width": "0"}, "normal", function() {
			$(this).hide();
			$(this).remove();
			try{
				$gameSystem.setTouchMoveEnabled(true);
			}
			catch(e){
				console.log(e);
			}
		});
	}
};

//ajax top 10 list
if(AXY.AjaxNetStuff.Param.EnableTopList){
	try{
	//display html first
	var temp = AXY.AjaxNetStuff.Param.URL.split("/");
	var AXY_LoginURL = temp[0]+'//'+temp[2]+'/Login';
	//console.log(AXY_LoginURL);
	var AXYAjaxTopListEntity;
	var AXYAjaxTopListTemplate = 
			"<style type=\"text/css\">.AXYAjaxTopList{position:fixed;"+
			String(AXY.AjaxNetStuff.Parameters['TopListHAlign'])+":"+
			AXY.AjaxNetStuff.Param.X+"px;"+
			String(AXY.AjaxNetStuff.Parameters['TopListVAlign'])+":"+
			AXY.AjaxNetStuff.Param.Y+"px;z-index:"+
			AXY.AjaxNetStuff.Param.zIndex+";width:"+
			AXY.AjaxNetStuff.Param.Width+"px;height:"+
			AXY.AjaxNetStuff.Param.Height+"px;font-size:"+
			AXY.AjaxNetStuff.Param.fontsize+"px;color:"+
			AXY.AjaxNetStuff.Param.TextColor+";background-color:"+
			AXY.AjaxNetStuff.Param.backgroundcolor+";opacity:"+
			AXY.AjaxNetStuff.Param.opacity+";pointer-events:none;}.AXYAjaxTopList .AXYAjaxTopListTable{width:100%;height:100%;display:none;padding:5px 30px;text-stroke:1px red;text-shadow:#000 1px 0 0,#000 0 1px 0,#000 -1px 0 0,#000 0 -1px 0;-webkit-text-shadow:#000 1px 0 0,#000 0 1px 0,#000 -1px 0 0,#000 0 -1px 0;-moz-text-shadow:#000 1px 0 0,#000 0 1px 0,#000 -1px 0 0,#000 0 -1px 0;text-align:center;border-collapse:collapse}.AXYAjaxTopListButton{color:#ff0;text-align:"+
			AXY.AjaxNetStuff.Param.TextAlign+"}.AXYAjaxTopListButton img{width:"+
			AXY.AjaxNetStuff.Param.ImgWidth+"px;height:"+
			AXY.AjaxNetStuff.Param.ImgHeight+"px;opacity:"+
			AXY.AjaxNetStuff.Param.ImgOpacity+";pointer-events:auto;}.AXYAjaxTopListLoginButton a,a:hover,a:link,a:visited,a:active{margin:0 5px 0 10px;opacity:"+
			AXY.AjaxNetStuff.Param.LoginButtonOpacity+";color:"+
			AXY.AjaxNetStuff.Param.LoginButtonColor+";text-stroke:1px red;text-shadow:#000 1px 0 0,#000 0 1px 0,#000 -1px 0 0,#000 0 -1px 0;-webkit-text-shadow:#000 1px 0 0,#000 0 1px 0,#000 -1px 0 0,#000 0 -1px 0;-moz-text-shadow:#000 1px 0 0,#000 0 1px 0,#000 -1px 0 0,#000 0 -1px 0;text-decoration:none;font-size:"+
			AXY.AjaxNetStuff.Param.LoginButtonFontSize+"px;pointer-events:auto;}<\/style><div class=\"AXYAjaxTopList\"><table class=\"AXYAjaxTopListTable\" border=\"1\"><\/table><div class=\"AXYAjaxTopListButton\"><img src=\"img/pictures/Arrow2.png\" class=\"AXYAjaxTopListArrowOpen\"><img src=\"img/pictures/Arrow8.png\" class=\"AXYAjaxTopListArrowClose\" style=\"display:none\"><a href=\""+
			'javascript:;'+"\" target=\"_blank\" class=\"AXYAjaxTopListLoginButton\">"+
			AXY.AjaxNetStuff.Param.LoginButtonText+"<\/a><\/div><\/div>";
	var AXYAjaxTopListTableTemplate = 
			"<thead><tr><th>"+
			AXY.AjaxNetStuff.Param.LastestText+"<\/th><th>"+
			AXY.AjaxNetStuff.Param.ActorText+"<\/th><th>"+
			AXY.AjaxNetStuff.Param.LevelText+"<\/th><th>"+
			AXY.AjaxNetStuff.Param.GoldText+"<\/th><th>"+
			AXY.AjaxNetStuff.Param.StepsText+"<\/th><th>"+
			AXY.AjaxNetStuff.Param.PlayTimeText+"<\/th><th>"+
			AXY.AjaxNetStuff.Param.SaveTimesText+"<\/th><th>"+
			AXY.AjaxNetStuff.Param.BattleTimesText+"<\/th><th>"+
			AXY.AjaxNetStuff.Param.VictoryTimesText+"<\/th><th>"+
			AXY.AjaxNetStuff.Param.EscapeTimesText+"<\/th><\/tr><\/thead><tbody class=\"AXYAjaxTopListTbody\"><tr><td colspan=\"10\">"+
			AXY.AjaxNetStuff.Param.LoadingText+"<\/td><\/tr><\/tbody>";
	var AXYAjaxTopListButtonTemplate = 
			AXY.AjaxNetStuff.Param.LoginButtonText;
	var AXYAjaxTopListTemplateCss =
			{
				'font-family':	$gameSystem ? Window_Base.prototype.standardFontFace : 'GameFont'
			};
	AXYAjaxTopListEntity = $('body').append(AXYAjaxTopListTemplate);
	$('.AXYAjaxTopList').css('font-family', $gameSystem ? Window_Base.prototype.standardFontFace : 'GameFont');
	$('.AXYAjaxTopListTable').html(AXYAjaxTopListTableTemplate);
	$('.AXYAjaxTopListLoginButton').text(AXYAjaxTopListButtonTemplate);
	$('.AXYAjaxTopListLoginButton').unbind('click touchstart').bind('click touchstart',function() {
		//$.toaster({ message : '手机版暂不支持登录', color:'red'});
		AXY_AjaxLogin.show();
	});
	
	//console.log($gameActors);
	//console.log(AXYAjaxTopListTemplateCss);
	var AXY_AjaxTopListURL = AXY.AjaxNetStuff.Param.URL.replace('zhongchou','rmmvgame').replace('product','rmmvgametoplist');
	var postjsonstr;
	
	setInterval(function()
	{
		if(!$gameParty){
			return;
		}
		if(!$gameActors){
			return;
		}
		//console.log($gameActors._data[$gameActors._data.length-1]);
		var gameActors_data = $gameActors._data[1] ? $gameActors._data[1] : $gameActors._data[$gameActors._data.length-1];
		
		/*if($gameParty._gold>500000 && $gameParty._steps<10000 && $gameSystem._framesOnSave<2160000){
			postjsonstr = '';
		}else{*/
			postjsonstr = JSON.stringify({
							gold: $gameParty._gold, 
							steps: $gameParty._steps, 
							name: gameActors_data._name, 
							level: gameActors_data['level'], 
							battlecount: $gameSystem._battleCount, 
							escapecount: $gameSystem._escapeCount, 
							wincount: $gameSystem._winCount, 
							savecount: $gameSystem._saveCount, 
							playtime: parseInt($gameSystem._framesOnSave/60), 
						});
		//}
		$.ajax({
			url: AXY_AjaxTopListURL,
			type: 'POST',
			dataType: 'json',
			data: {sid: AXY.AjaxNetStuff.Param.sid, jsonstr:postjsonstr},
			success: function (data) {
				//console.log(data);
				if (data.status) {
					//$('.AXYAjaxTopListTbody').empty();
					//console.log(data);
					var str = '';
					$.each(data['jsonstr'], function(index) {
						var obj1 = data['jsonstr'][index];
						//console.log(obj1.jsonstr);
						var obj = $.parseJSON($.parseJSON(obj1.jsonstr));
						//console.log(obj);
						var time1 = new Date((obj1.lasttime).replace(new RegExp("-","gm"),"/")).Format("hh:mm"); 
						str += '<tr>';
						str += '<td>' + time1 + '</td>';
						if(obj1.userid != 0){
							str += '<td>' + obj.name + '</td>';
						}else{
							str += '<td>游客: ' + obj.name + '</td>';
						}
						
						str += '<td>' + obj.level + '</td>';
						str += '<td>' + Math.ceil(obj.gold/10000) + '万</td>';
						str += '<td>' + obj.steps + '</td>';
						str += '<td>' + formatHours(obj.playtime) + '</td>';
						str += '<td>' + obj.savecount + '</td>';
						str += '<td>' + obj.battlecount + '</td>';
						str += '<td>' + obj.wincount + '</td>';
						str += '<td>' + obj.escapecount + '</td>';
						str += '</tr>';
						
						
					});
					str += "<tr><td colspan=10>众筹游戏《"+data.gamename+"》共有"+data.count+"个玩家</td></tr>";
					$('.AXYAjaxTopListTbody').html(str);
					if(data.uid != null){
						$('.AXYAjaxTopListLoginButton').css("display", 'none');
						AXY.AjaxNetStuff.Param.Loggedin = true;
					}
				} else{
					//console.log(data);
				};
			},
			error:function (jqXHR) {
				//console.log(jqXHR);
			}
		});
	}, 60000);
	
	//then bind action
	var AXY_AjaxTopList = {
		show: function () {
			$('.AXYAjaxTopList').css('font-family', $gameSystem ? Window_Base.prototype.standardFontFace : 'GameFont');
			$('.AXYAjaxTopListTable').html(AXYAjaxTopListTableTemplate);
			$('.AXYAjaxTopListLoginButton').text(AXYAjaxTopListButtonTemplate);
			$('.AXYAjaxTopListTable').stop().show().animate({"height": "98%"}, "normal");
		},
		hide: function () {
			$('.AXYAjaxTopListTable').stop().animate({"height": "0"}, "normal", function() {
				$(this).hide();
				//$(this).remove();
			});
		}
	};

	//last bind the click
	$('.AXYAjaxTopListArrowOpen').unbind('click touchstart').bind('click touchstart',function() {
		if(!$gameParty){
			$.toaster({ message : "Not Ready!"});
			return;
		}
		//console.log($gameActors);

		AXY_AjaxTopList.show();
		$('.AXYAjaxTopListArrowOpen').hide();
		$('.AXYAjaxTopListArrowClose').show();
		//$('.AXYAjaxTopListTbody').empty();
		$('.AXYAjaxTopListTbody').html("<tr><td colspan=10>"+AXY.AjaxNetStuff.Param.LoadingText+"</td></tr>");
		/*if($gameParty._gold>500000 && $gameParty._steps<10000 && $gameSystem._framesOnSave<2160000){
			postjsonstr = '';
		}else{*/
			postjsonstr = JSON.stringify({
							gold: $gameParty._gold, 
							steps: $gameParty._steps, 
							name: $gameActors._data[1]._name, 
							level: $gameActors._data[1]['level'], 
							battlecount: $gameSystem._battleCount, 
							escapecount: $gameSystem._escapeCount, 
							wincount: $gameSystem._winCount, 
							savecount: $gameSystem._saveCount, 
							playtime: parseInt($gameSystem._framesOnSave/60), 
						});
		//}
		$.ajax({
			url: AXY_AjaxTopListURL,
			type: 'POST',
			dataType: 'json',
			data: {sid: AXY.AjaxNetStuff.Param.sid, jsonstr:postjsonstr},
			success: function (data) {
				if (data.status) {
					$('.AXYAjaxTopListTbody').empty();
					//console.log(data);
					$.each(data['jsonstr'], function(index) {
						var obj1 = data['jsonstr'][index];
						//console.log(obj1.jsonstr);
						var obj = $.parseJSON($.parseJSON(obj1.jsonstr));
						//console.log(obj);
						var time1 = new Date((obj1.lasttime).replace(new RegExp("-","gm"),"/")).Format("hh:mm"); 
						var str = '<td>' + time1 + '</td>';
						if(obj1.userid != 0){
							str += '<td>' + obj.name + '</td>';
						}else{
							str += '<td>游客: ' + obj.name + '</td>';
						}
						
						str += '<td>' + obj.level + '</td>';
						str += '<td>' + Math.ceil(obj.gold/10000) + '万</td>';
						str += '<td>' + obj.steps + '</td>';
						str += '<td>' + formatHours(obj.playtime) + '</td>';
						str += '<td>' + obj.savecount + '</td>';
						str += '<td>' + obj.battlecount + '</td>';
						str += '<td>' + obj.wincount + '</td>';
						str += '<td>' + obj.escapecount + '</td>';
						
						$('.AXYAjaxTopListTbody').append("<tr>"+str+"</tr>");
					});
					$('.AXYAjaxTopListTbody').append("<tr><td colspan=10>众筹游戏《"+data.gamename+"》共有"+data.count+"个玩家</td></tr>");
					
					if(data.uid != null){
						$('.AXYAjaxTopListLoginButton').css("display", 'none');
						
						//logingift
						if(AXY.AjaxNetStuff.Param.EnableLoginGift){
							if(AXY.AjaxNetStuff.Param.Loggedin){
								return;
							}
							
							//console.log($gamePlayer);
							//console.log($gameMap);
							if(!$gameMap._mapId){
								return;
							}
							var arrLoginGift = String(AXY.AjaxNetStuff.Parameters['LoginGift']).split(';');
							console.log(arrLoginGift);
							$.each(arrLoginGift, function(index) {
								var arrLoginGiftItem = arrLoginGift[index].split(':');
								console.log(arrLoginGiftItem);
								arrLoginGiftItem[0] = parseInt(arrLoginGiftItem[0]);
								arrLoginGiftItem[1] = parseInt(arrLoginGiftItem[1]);
								arrLoginGiftItem[2] = parseInt(arrLoginGiftItem[2]);
								switch(arrLoginGiftItem[0]){
									case 0:
										$gameParty.gainGold(arrLoginGiftItem[2],0,0);
										if(!AXY.Toast.Param.DisplayGainGold){
											$.toaster({ message : "+"+arrLoginGiftItem[2]+TextManager.currencyUnit});
										}
										break;
									case 1:
										$gameParty.gainItem($dataItems[arrLoginGiftItem[1]],arrLoginGiftItem[2],0,0);
										if(!AXY.Toast.Param.DisplayGainItem){
											$.toaster({ message : "+"+arrLoginGiftItem[2]+$dataItems[arrLoginGiftItem[1]].name});
										}
										break;
									case 2:
										$gameParty.gainItem($dataWeapons[arrLoginGiftItem[1]], arrLoginGiftItem[2],0,0,0);
										if(!AXY.Toast.Param.DisplayGainItem){
											$.toaster({ message : "+"+arrLoginGiftItem[2]+$dataWeapons[arrLoginGiftItem[1]].name});
										}
										break;
									case 3:
										$gameParty.gainItem($dataArmors[arrLoginGiftItem[1]], arrLoginGiftItem[2],0,0,0);
										if(!AXY.Toast.Param.DisplayGainItem){
											$.toaster({ message : "+"+arrLoginGiftItem[2]+$dataArmors[arrLoginGiftItem[1]].name});
										}
										break;
									default:
										//console.log(typeof(obj[index].num));
										break;
								}
							});
							
							setTimeout(function()
							{
								$.toaster({ message : "众筹游戏《"+data.gamename+"》诚邀您参与众筹！"});
								//AXY_AjaxLogin.hide();
							}, 3000);
						}
						AXY.AjaxNetStuff.Param.Loggedin = true;
					}
				} else{
					console.log(data);
					$('.AXYAjaxTopListTbody').html("<tr><td colspan=10>"+data.info+data.error+"</td></tr>");
					//Silv.ItemLog.PluginCommand('axy.AjaxNetStuff', ['gold',123]);
					/*var args="itemlog gold 123".split(" ");
					var command =args.shift();
					Game_Interpreter.prototype.pluginCommand(command,args);*/
				};
			},
			error:function (jqXHR) {
				$('.AXYAjaxTopListTbody').html("<tr><td colspan=10>"+jqXHR.status+"</td></tr>");
				console.log(jqXHR);
			}
		});
	});
	$('.AXYAjaxTopListArrowClose').unbind('click touchstart').bind('click touchstart',function() {
		AXY_AjaxTopList.hide();
		$('.AXYAjaxTopListArrowOpen').show();
		$('.AXYAjaxTopListArrowClose').hide();
		
	});
	}
	catch(e){
		console.log(e);
	}
}

//ajax login
var AXY_AjaxLogin = {
	show: function () {
		var AXYAjaxLoginEntity;
		var AXYAjaxLoginTemplate = 
				'<div class="AXYAjaxLogin" id="AXYAjaxLogin">' +
					'<div class="AXYAjaxLoginBG"></div>' +
					'<input type="text" class="AXYAjaxLoginInput" id="AXYAjaxLoginInputName" placeholder="输入用户名" />' +
					'<input type="password" class="AXYAjaxLoginInput" id="AXYAjaxLoginInputPwd" placeholder="输入密码" />' +
					'<input type="button" class="AXYAjaxLoginButton" id="AXYAjaxLoginButtonUse" value="'+AXYAjaxTopListButtonTemplate+'" />' +
					'<input type="button" class="AXYAjaxLoginButton" id="AXYAjaxLoginButtonReg" value="还没账号？" />' +
					'<input type="button" class="AXYAjaxLoginButton" id="AXYAjaxLoginButtonClear" value="清空" />' +
					'<input type="button" class="AXYAjaxLoginButton" id="AXYAjaxLoginButtonClose" value="关闭" />' +
				'</div>';
		var AXYAjaxLoginStyleCss = 
				'.AXYAjaxLogin{position:fixed;top:10px;left:.5%;z-index:10000;display:none;margin:0 auto;width:0%;height:80px;text-align:center;}'+
				'.AXYAjaxLogin .AXYAjaxLoginBG{position:absolute;width:100%;height:100%;border:3px solid #fff;border-radius:10px;background:#000;opacity:.5}'+
				'.AXYAjaxLogin .AXYAjaxLoginInput{margin:15px 0;text-align:center;width:20%;height:50px;imeMode:active}'+
				'.AXYAjaxLogin .AXYAjaxLoginButton,.AXYAjaxLogin .AXYAjaxLoginInput{position:relative;outline:0;border:1px solid #fff;border-radius:5px;background-color:rgba(0,0,0,0.4);color:#fff;font-size:24px;}'+
				'.AXYAjaxLogin .AXYAjaxLoginButton{top:0;z-index:10000;margin-left:2%;width:10%;height:3pc;word-spacing:20px;cursor:pointer}';
		var css =
				{
					'font-family':	$gameSystem ? Window_Base.prototype.standardFontFace : 'GameFont'
				};
		AXYAjaxLoginEntity = $('body').append(AXYAjaxLoginTemplate);
		AXYAjaxLoginEntity = $('#AXYAjaxLogin').append('<style type="text/css">'+AXYAjaxLoginStyleCss+'</style>');
		$('#AXYAjaxLoginInputName').css(css);
		$('#AXYAjaxLoginInputPwd').css(css);
		$('.AXYAjaxLoginButton').css(css);
		//console.log(css);
		//console.log($gameParty);
		//console.log($gameSystem);
		//console.log(TextManager.currencyUnit);

		$('#AXYAjaxLogin').stop().show().animate({"width": "98%"}, "normal");
		try{
			$gameSystem.setTouchMoveEnabled(false);
		}
		catch(e){
			console.log(e);
		}
		$('#AXYAjaxLoginInputName').focus();

		$('#AXYAjaxLoginInputName').keydown(function (e) {
            if (e.keyCode == 8) {
				var _name = this.value.slice(0, this.value.length - 1);
				this.value = _name;
            }
        }); 
		$('#AXYAjaxLoginInputName').unbind('click touchend').bind('click touchend',function () {
            $('#AXYAjaxLoginInputName').focus();
        }); 
		$('#AXYAjaxLoginInputPwd').keydown(function (e) {
            if (e.keyCode == 8) {
				var _name = this.value.slice(0, this.value.length - 1);
				this.value = _name;
            }
        }); 
		$('#AXYAjaxLoginInputPwd').unbind('click touchend').bind('click touchend',function () {
            $('#AXYAjaxLoginInputPwd').focus();
        }); 
		$('#AXYAjaxLoginButtonReg').unbind('click touchend').bind('click touchend',function () {
            window.open(AXY_LoginURL);
        }); 
		//console.log($('#AXYAjaxLoginInput'));
		
		$('#AXYAjaxLoginButtonUse').unbind('click touchend').bind('click touchend',function() {
			if($('#AXYAjaxLoginButtonUse')[0].disabled){
				//console.log($('#AXYAjaxLoginButtonUse')[0].disabled);
				return;
			}
			//console.log($('#AXYAjaxLoginButtonUse'));
			//console.log($('#AXYAjaxLoginButtonUse')[0].disabled);

			$('#AXYAjaxLoginButtonUse').attr("disabled", true);
			$('#AXYAjaxLoginButtonUse').val("loading");
			//console.log($('#AXYAjaxLoginButtonUse'));
			//console.log(typeof($('#AXYAjaxLoginButtonUse')[0].disabled));
			//return;
			var inputName = $('#AXYAjaxLoginInputName').val(); //$('#AXYAjaxLoginInputName').val().replace(/ /g, "");
			inputName = inputName.replace(/<\/?[^>]*>/gim,"");//去掉所有的html标记
			inputName = inputName.replace(/(^\s+)|(\s+$)/g,"");//去掉前后空格
			//inputName = inputName.replace(/\s/g,"");//去除文章中间空格
			var inputPwd = $('#AXYAjaxLoginInputPwd').val(); //$('#AXYAjaxLoginInputPwd').val().replace(/ /g, "");
			inputPwd = inputPwd.replace(/<\/?[^>]*>/gim,"");//去掉所有的html标记
			inputPwd = inputPwd.replace(/(^\s+)|(\s+$)/g,"");//去掉前后空格
			//inputPwd = inputPwd.replace(/\s/g,"");//去除文章中间空格
			//console.log($('#AXYAjaxLoginInput'));
			//console.log($('#AXYAjaxLoginInput').val());
			//console.log(inputcoupon);
			//console.log(str);
			//console.log(result);
			//console.log(ss);


			if(!inputName || !inputPwd){
				//console.log('代码不能为空');
				$.toaster({ message : '用户名和密码不能为空', color:'red'});
				$('#AXYAjaxLoginButtonUse').attr("disabled", false);
				$('#AXYAjaxLoginButtonUse').val(AXYAjaxTopListButtonTemplate);
				return;
			}
			//else{
			$.toaster({ message : '正在登录...', color:'white'});
			var AXY_AjaxLoginURL = AXY.AjaxNetStuff.Param.URL.replace('zhongchou','rmmvgame').replace('product','rmmvgamelogin');
			$.ajax({
				url: AXY_AjaxLoginURL,
				type: 'POST',
				dataType: 'json',
				data: {username: inputName, password: inputPwd},
				success: function (data) {
					//console.log(data);
					if (data.status) {
						$.toaster({ message : "登录成功！"});
						
						if(data.uid != null){
							$('.AXYAjaxTopListLoginButton').css("display", 'none');
							
							//logingift
							if(AXY.AjaxNetStuff.Param.EnableLoginGift){
								if(AXY.AjaxNetStuff.Param.Loggedin){
									return;
								}
								//console.log($gamePlayer);
								//console.log($gameMap);
								if(!$gameMap._mapId){
									return;
								}
								var arrLoginGift = String(AXY.AjaxNetStuff.Parameters['LoginGift']).split(';');
								//console.log(arrLoginGift);
								$.each(arrLoginGift, function(index) {
									var arrLoginGiftItem = arrLoginGift[index].split(':');
									//console.log(arrLoginGiftItem);
									arrLoginGiftItem[0] = parseInt(arrLoginGiftItem[0]);
									arrLoginGiftItem[1] = parseInt(arrLoginGiftItem[1]);
									arrLoginGiftItem[2] = parseInt(arrLoginGiftItem[2]);
									switch(arrLoginGiftItem[0]){
										case 0:
											$gameParty.gainGold(arrLoginGiftItem[2],0,0);
											if(!AXY.Toast.Param.DisplayGainGold){
												$.toaster({ message : "+"+arrLoginGiftItem[2]+TextManager.currencyUnit});
											}
											break;
										case 1:
											$gameParty.gainItem($dataItems[arrLoginGiftItem[1]],arrLoginGiftItem[2],0,0);
											if(!AXY.Toast.Param.DisplayGainItem){
												$.toaster({ message : "+"+arrLoginGiftItem[2]+$dataItems[arrLoginGiftItem[1]].name});
											}
											break;
										case 2:
											$gameParty.gainItem($dataWeapons[arrLoginGiftItem[1]], arrLoginGiftItem[2],0,0,0);
											if(!AXY.Toast.Param.DisplayGainItem){
												$.toaster({ message : "+"+arrLoginGiftItem[2]+$dataWeapons[arrLoginGiftItem[1]].name});
											}
											break;
										case 3:
											$gameParty.gainItem($dataArmors[arrLoginGiftItem[1]], arrLoginGiftItem[2],0,0,0);
											if(!AXY.Toast.Param.DisplayGainItem){
												$.toaster({ message : "+"+arrLoginGiftItem[2]+$dataArmors[arrLoginGiftItem[1]].name});
											}
											break;
										default:
											//console.log(typeof(obj[index].num));
											break;
									}
								});
							}
							AXY_AjaxLogin.hide();
							AXY.AjaxNetStuff.Param.Loggedin = true;
							AXY.AjaxNetStuff.Param.sid = data.sid;
							//alert(AXY.AjaxNetStuff.Param.sid);
							//alert(data.sid);
							//alert(data.uid);
							setTimeout(function(){
								$.toaster({ message : "众筹游戏《"+data.gamename+"》诚邀您参与众筹！"});
							}, 3000);
							if(AXY.AjaxNetStuff.Param.LoginCommonEventId > 0){
								$gameTemp.reserveCommonEvent(AXY.AjaxNetStuff.Param.LoginCommonEventId);
							}
						}
					} else{
						console.log(data);
						$.toaster({ message : data.info+', ERRORCODE: '+data.error, color:'red'});
					};
					$('#AXYAjaxLoginButtonUse').attr("disabled", false);
					$('#AXYAjaxLoginButtonUse').val(AXYAjaxTopListButtonTemplate);
				},
				error:function (XMLHttpRequest, textStatus, errorThrown) {
					console.log(XMLHttpRequest);
					console.log(textStatus);
					console.log(errorThrown);
					$.toaster({ title: 'ERROR: ', message : textStatus+' '+errorThrown, color:'red'});
					$('#AXYAjaxLoginButtonUse').attr("disabled", false);
					$('#AXYAjaxLoginButtonUse').val(AXYAjaxTopListButtonTemplate);
				},
				complete:function (XMLHttpRequest, textStatus) {
					//console.log(XMLHttpRequest);
					//console.log(textStatus);
					$.toaster({ title: 'COMPLETE: ', message : textStatus, color:'gray'});
					$('#AXYAjaxLoginButtonUse').attr("disabled", false);
					$('#AXYAjaxLoginButtonUse').val(AXYAjaxTopListButtonTemplate);
				}
			});
			//}
		});
		$('#AXYAjaxLoginButtonClear').unbind('click touchstart').bind('click touchstart',function() {
			$('#AXYAjaxLoginInputName').val('').focus();
			$('#AXYAjaxLoginInputPwd').val('');
		});
		$('#AXYAjaxLoginButtonClose').unbind('click touchstart').bind('click touchstart',function() {
			AXY_AjaxLogin.hide();
		});
	},
	hide: function () {
		$('#AXYAjaxLogin').stop().animate({"width": "0"}, "normal", function() {
			$(this).hide();
			$(this).remove();
			try{
				$gameSystem.setTouchMoveEnabled(true);
			}
			catch(e){
				console.log(e);
			}
		});
	}
};

//ajax coupon
if (AXY.AjaxNetStuff.Param.EnableCoupon) {
	//=============================================================================
	// ** Window MenuCommand
	//=============================================================================	

	//==============================
	// * make Command List
	//==============================
	AXY.AjaxNetStuff.Alias.addOriginalCommandsCoupon = Window_MenuCommand.prototype.addOriginalCommands;
	Window_MenuCommand.prototype.addOriginalCommands = function() {
		AXY.AjaxNetStuff.Alias.addOriginalCommandsCoupon.call(this);
		this.addCommand(AXY.AjaxNetStuff.Param.CouponText, 'coupon', true);
	};
		
	//=============================================================================
	// ** Scene Menu
	//=============================================================================	

	//==============================
	// * create Command Window
	//==============================
	AXY.AjaxNetStuff.Alias.createCommandWindowCoupon = Scene_Menu.prototype.createCommandWindow;
	Scene_Menu.prototype.createCommandWindow = function() {
		AXY.AjaxNetStuff.Alias.createCommandWindowCoupon.call(this); 
		this._commandWindow.setHandler('coupon',      this.commandCoupon.bind(this));
		/*if (Imported.MOG_TimeSystem && Moghunter.timeWindow_menu) {	
			this._commandWindow.height -= this._commandWindow.itemHeight();
		};*/
	};

	//==============================
	// * Cloud Save
	//==============================
	Scene_Menu.prototype.commandCoupon = function() {
		AXY_AjaxCoupon.show();
		// Close option window
		SceneManager.pop();	
	};
	
	var AXY_AjaxCoupon = {
		show: function () {
			var AXYAjaxCouponEntity;
			var AXYAjaxCouponTemplate = 
					'<div class="AXYAjaxCoupon" id="AXYAjaxCoupon">' +
						'<div class="AXYAjaxCouponBG"></div>' +
						'<input type="text" class="AXYAjaxCouponInput" id="AXYAjaxCouponInput" placeholder="按 Ctrl+V 粘贴" />' +
						'<input type="button" class="AXYAjaxCouponButton" id="AXYAjaxCouponButtonUse" value="兑换" />' +
						'<input type="button" class="AXYAjaxCouponButton" id="AXYAjaxCouponButtonClear" value="清空" />' +
						'<input type="button" class="AXYAjaxCouponButton" id="AXYAjaxCouponButtonClose" value="关闭" />' +
					'</div>';
			var AXYAjaxCouponStyleCss = 
					'.AXYAjaxCoupon{position:fixed;top:10px;left:.5%;z-index:10000;display:none;margin:0 auto;width:0%;height:80px;text-align:center;}'+
					'.AXYAjaxCoupon .AXYAjaxCouponBG{position:absolute;width:100%;height:100%;border:3px solid #fff;border-radius:10px;background:#000;opacity:.5}'+
					'.AXYAjaxCoupon .AXYAjaxCouponInput{margin:15px 0;text-align:center;width:30%;height:50px;imeMode:active}'+
					'.AXYAjaxCoupon .AXYAjaxCouponButton,.AXYAjaxCoupon .AXYAjaxCouponInput{position:relative;outline:0;border:1px solid #fff;border-radius:5px;background-color:rgba(0,0,0,0.4);color:#fff;font-size:24px;}'+
					'.AXYAjaxCoupon .AXYAjaxCouponButton{top:0;z-index:10000;margin-left:2%;width:10%;height:3pc;word-spacing:20px;cursor:pointer}';
			var css =
					{
						'font-family':	$gameSystem ? Window_Base.prototype.standardFontFace : 'GameFont'
					};
			AXYAjaxCouponEntity = $('body').append(AXYAjaxCouponTemplate);
			AXYAjaxCouponEntity = $('#AXYAjaxCoupon').append('<style type="text/css">'+AXYAjaxCouponStyleCss+'</style>');
			$('#AXYAjaxCouponInput').css(css);
			$('.AXYAjaxCouponButton').css(css);
			//console.log(css);
			//console.log($gameParty);
			//console.log($gameSystem);
			//console.log(TextManager.currencyUnit);

			$('#AXYAjaxCoupon').stop().show().animate({"width": "98%"}, "normal");
			$gameSystem.setTouchMoveEnabled(false);
			$('#AXYAjaxCouponInput').focus();

			$('#AXYAjaxCouponInput').keydown(function (e) {
				if (e.keyCode == 8) {
					var _name = this.value.slice(0, this.value.length - 1);
					this.value = _name;
				}
			}); 
			$('#AXYAjaxCouponInput').unbind('click touchend').bind('click touchend',function () {
				$('#AXYAjaxCouponInput').focus();
			}); 
			//console.log($('#AXYAjaxCouponInput'));
			
			$('#AXYAjaxCouponButtonUse').unbind('click touchend').bind('click touchend',function() {
				if($('#AXYAjaxCouponButtonUse')[0].disabled){
					//console.log($('#AXYAjaxCouponButtonUse')[0].disabled);
					return;
				}
				//console.log($('#AXYAjaxCouponButtonUse'));
				//console.log($('#AXYAjaxCouponButtonUse')[0].disabled);

				$('#AXYAjaxCouponButtonUse').attr("disabled", true);
				$('#AXYAjaxCouponButtonUse').val("loading");
				//console.log($('#AXYAjaxCouponButtonUse'));
				//console.log(typeof($('#AXYAjaxCouponButtonUse')[0].disabled));
				//return;
				var inputcoupon = $('#AXYAjaxCouponInput').val().replace(/ /g, "");
				inputcoupon = inputcoupon.replace(/<\/?[^>]*>/gim,"");//去掉所有的html标记
				inputcoupon = inputcoupon.replace(/(^\s+)|(\s+$)/g,"");//去掉前后空格
				inputcoupon = inputcoupon.replace(/\s/g,"");//去除文章中间空格
				//console.log($('#AXYAjaxCouponInput'));
				//console.log($('#AXYAjaxCouponInput').val());
				//console.log(inputcoupon);
				//console.log(str);
				//console.log(result);
				//console.log(ss);


				if(!inputcoupon){
					//console.log('代码不能为空');
					$.toaster({ message : '代码不能为空', color:'red'});
					$('#AXYAjaxCouponButtonUse').attr("disabled", false);
					$('#AXYAjaxCouponButtonUse').val("兑换");
					return;
				}
				//else{
				$.toaster({ message : '正在验证...', color:'white'});
				var AXY_AjaxCouponURL = AXY.AjaxNetStuff.Param.URL.replace('zhongchou','rmmvgame').replace('product','rmmvgamecoupon');
				$.ajax({
					url: AXY_AjaxCouponURL,
					type: 'POST',
					dataType: 'json',
					data: {sid: AXY.AjaxNetStuff.Param.sid, coupon: inputcoupon},
					success: function (data) {
						//console.log(data);
						if (data.status) {
							var obj = $.parseJSON(data['jsonstr']);
							//console.log(obj);
							$.each(obj, function(index) {
								//console.log(obj[index]);
								switch(obj[index].item){
									case 0:
										$gameParty.gainGold(obj[index].num,0,0);
										if(!AXY.Toast.Param.DisplayGainGold){
											$.toaster({ message : "+"+obj[index].num+TextManager.currencyUnit});
										}
										break;
									case 1:
										$gameParty.gainItem($dataItems[obj[index].id],obj[index].num,0,0);
										if(!AXY.Toast.Param.DisplayGainItem){
											$.toaster({ message : "+"+obj[index].num+$dataItems[obj[index].id].name});
										}
										break;
									case 2:
										$gameParty.gainItem($dataWeapons[obj[index].id], obj[index].num,0,0,0);
										if(!AXY.Toast.Param.DisplayGainItem){
											$.toaster({ message : "+"+obj[index].num+$dataWeapons[obj[index].id].name});
										}
										break;
									case 3:
										$gameParty.gainItem($dataArmors[obj[index].id], obj[index].num,0,0,0);
										if(!AXY.Toast.Param.DisplayGainItem){
											$.toaster({ message : "+"+obj[index].num+$dataArmors[obj[index].id].name});
										}
										break;
									default:
										//console.log(typeof(obj[index].num));
										break;
								}
							});
							
							setTimeout(function()
							{
								$.toaster({ message : "众筹游戏《"+data.gamename+"》感谢您的支持！"});
								AXY_AjaxCoupon.hide();
							}, 3000);
							
						} else{
							console.log(data);
							$.toaster({ message : data.info+', ERRORCODE: '+data.error, color:'red'});
						};
						$('#AXYAjaxCouponButtonUse').attr("disabled", false);
						$('#AXYAjaxCouponButtonUse').val("兑换");
					},
					error:function (XMLHttpRequest, textStatus, errorThrown) {
						console.log(XMLHttpRequest);
						console.log(textStatus);
						console.log(errorThrown);
						$.toaster({ title: 'ERROR: ', message : textStatus+' '+errorThrown, color:'red'});
						$('#AXYAjaxCouponButtonUse').attr("disabled", false);
						$('#AXYAjaxCouponButtonUse').val("兑换");
					},
					complete:function (XMLHttpRequest, textStatus) {
						console.log(XMLHttpRequest);
						console.log(textStatus);
						$.toaster({ title: 'COMPLETE: ', message : textStatus, color:'gray'});
						$('#AXYAjaxCouponButtonUse').attr("disabled", false);
						$('#AXYAjaxCouponButtonUse').val("兑换");
					}
				});
				//}
			});
			$('#AXYAjaxCouponButtonClear').unbind('click touchstart').bind('click touchstart',function() {
				$('#AXYAjaxCouponInput').val('').focus();
			});
			$('#AXYAjaxCouponButtonClose').unbind('click touchstart').bind('click touchstart',function() {
				AXY_AjaxCoupon.hide();
			});
		},
		hide: function () {
			$('#AXYAjaxCoupon').stop().animate({"width": "0"}, "normal", function() {
				$(this).hide();
				$(this).remove();
				$gameSystem.setTouchMoveEnabled(true);
			});
		}
	};
}

//ajax ver check
if(AXY.AjaxNetStuff.Param.EnableVerCheck){
	//display html first
	//console.log(AXY_AjaxLoginURL);
	var width = String(AXY.AjaxNetStuff.Parameters['VerCheckWidth']);
	if(width.indexOf("%") != -1){
		var widthpx = width;
	}
	else{
		var widthpx = width+'px';
	}

	var AXYAjaxVerCheckEntity;
	var AXYAjaxVerCheckTemplateStyle = 
			"<style type=\"text/css\">.AXYAjaxVerCheck{position:fixed;top:"+
			parseInt(AXY.AjaxNetStuff.Parameters['VerCheckY'])+"px;left:"+
			parseInt(AXY.AjaxNetStuff.Parameters['VerCheckX'])+"px;z-index:"+
			parseInt(AXY.AjaxNetStuff.Parameters['zIndex'])+";margin:0 auto;width:"+
			widthpx+";color:"+
			String(AXY.AjaxNetStuff.Parameters['VerCheckTextColor'])+";background-color:"+
			String(AXY.AjaxNetStuff.Parameters['VerCheckbackgroundcolor'])+";text-align:"+
			String(AXY.AjaxNetStuff.Parameters['VerCheckTextAlign'])+";opacity:"+
			parseFloat(AXY.AjaxNetStuff.Parameters['VerCheckopacity'])+";}<\/style>";
	var AXYAjaxVerCheckTemplateDiv = "<div class=\"AXYAjaxVerCheck\">"+
	String(AXY.AjaxNetStuff.Parameters['VerCheckingText'])+"</div>";
	var AXYAjaxVerCheckTemplateCss =
			{
				'font-family':	$gameSystem ? Window_Base.prototype.standardFontFace : 'GameFont'
			};
	AXYAjaxVerCheckEntity = $('body').append(AXYAjaxVerCheckTemplateStyle);
	AXYAjaxVerCheckEntity = $('body').append(AXYAjaxVerCheckTemplateDiv);
	$('.AXYAjaxVerCheck').css('font-family', $gameSystem ? Window_Base.prototype.standardFontFace : 'GameFont');
	
	//console.log($gameSystem);
	//console.log(AXYAjaxVerCheckTemplateCss);
	
	//then bind action
	var AXY_AjaxVerCheck = {
		show: function () {
			$('.AXYAjaxVerCheck').append(AXYAjaxVerCheckTemplateStyle);
			$('.AXYAjaxVerCheck').append(AXYAjaxVerCheckTemplateDiv);
			$('.AXYAjaxVerCheck').css('font-family', $gameSystem ? Window_Base.prototype.standardFontFace : 'GameFont');
			$('.AXYAjaxVerCheck').stop().show().animate({"height": "98%"}, "normal");
		},
		hide: function () {
			$('.AXYAjaxVerCheck').stop().animate({"height": "0"}, "normal", function() {
				$(this).hide();
				$(this).remove();
			});
		}
	};

	//onready auto run
	$(document).ready(function(){
		/*if(!$gameParty){
			return;
		}*/
		var AXY_AjaxVerCheckURL = AXY.AjaxNetStuff.Param.URL.replace('zhongchou','rmmvgame').replace('product','rmmvgamevercheck');
		$.ajax({
			url: AXY_AjaxVerCheckURL,
			type: 'POST',
			dataType: 'json',
			data: {jsonstr:''},
			success: function (data) {
				if (data.status) {
					//console.log(data);
					if(data.version <= parseFloat(AXY.AjaxNetStuff.Parameters['Version'])){
						$('.AXYAjaxVerCheck').html(String(AXY.AjaxNetStuff.Parameters['NoNewText']));
						setTimeout(function()
						{
							AXY_AjaxVerCheck.hide();
						}, 1000);
					}
					else{
						$('.AXYAjaxVerCheck').html(String(AXY.AjaxNetStuff.Parameters['HaveNewText'])+data.version+"，<a id='AXYAjaxVerCheckHaveNewLink' href=\""+AXY.AjaxNetStuff.Param.URL+"\" target=\"_blank\">"+String(AXY.AjaxNetStuff.Parameters['LinkText'])+"</a>");
						$('#AXYAjaxVerCheckHaveNewLink').unbind('touchstart').bind('touchstart',function() {
							//$.toaster({ message : '手机版暂不支持登录', color:'red'});
							window.open(AXY.AjaxNetStuff.Param.URL);
						});
						setTimeout(function()
						{
							AXY_AjaxVerCheck.hide();
						}, 3000);
					}
					
				} else{
					console.log(data);
					$('.AXYAjaxVerCheck').html(""+data.info+data.error+"");
				};
			},
			error:function (jqXHR) {
				$('.AXYAjaxVerCheck').html(""+jqXHR.status+"");
				console.log(jqXHR);
			}
		});
	});
}
